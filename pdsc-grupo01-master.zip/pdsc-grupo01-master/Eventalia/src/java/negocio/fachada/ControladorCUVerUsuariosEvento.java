package negocio.fachada;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Usuario;


public class ControladorCUVerUsuariosEvento {
    public ArrayList<Usuario> getUsuariosEvento( String filtroE, int idEvento) {
        Usuario us=new Usuario();
        ArrayList users=us.getListaUsuariosFiltrados(filtroE, idEvento);
        ArrayList<Usuario> usuarios = new ArrayList<>();       
        int i;
              for(i=0;i<users.size();i+=4){
                    usuarios.add(new Usuario((int)users.get(i), users.get(i+1).toString(), users.get(i+2).toString(), 0, users.get(i+3).toString(),null,null,false));
            }
            return usuarios;
    }
}
