/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio.fachada;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Sesion;
/**
 *
 * @author Ivan
 */
public class ControladorCUVerSesionesEvento {
    public ArrayList<Sesion> getSesionevento(int idEvento){
        Sesion ev=new Sesion();
        ArrayList infoSes=ev.getListaSesionesEvento(idEvento);
        ArrayList<Sesion> sesiones = new ArrayList<>();       
        int i;
              for(i=0;i<infoSes.size();i+=6){
                sesiones.add(new Sesion((int)infoSes.get(i), infoSes.get(i+1).toString(), (int)infoSes.get(i+5), null, (Time)infoSes.get(i+2),null,0,infoSes.get(i+3).toString(),(Date)infoSes.get(i+4)));
              }
            return sesiones;
    }
}
