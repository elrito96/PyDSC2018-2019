package negocio.fachada;

import negocio.modelos.Sesion;

public class ControladorCURegistrarAsistencia {

    public void registrarAsistencia(int idSesion, String[] seleccion) {
  
        Sesion se = new Sesion(idSesion,null, 0, null, null, null, 0,null,null);
        se.registraAsistenciaSesion(seleccion);
    }
    
}
