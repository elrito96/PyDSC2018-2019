package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import javax.servlet.http.HttpSession;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;

public class ControladorCURechazarCondicionEvento {

    public void rechazarCondicionEvento(String condiciones,int idEvento, int estado, String nombre) {
        Evento ev = new Evento();
        ev.setIdEvento(idEvento);
        ev.setEstado(estado);
        ev.setNombre(nombre);
        ev.setCondiciones(condiciones);
        ev.rechazarCondicionEvento();
    }
    
}
