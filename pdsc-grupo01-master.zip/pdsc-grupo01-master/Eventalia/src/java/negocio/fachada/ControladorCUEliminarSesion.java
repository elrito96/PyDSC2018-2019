package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import javax.servlet.http.HttpSession;
import negocio.modelos.Sesion;
import negocio.modelos.Usuario;

public class ControladorCUEliminarSesion {

    public void eliminaSesion(int idSesion) {
        
        Sesion se = new Sesion(idSesion,null, 0, null, null, null,0,null,null);
           System.out.println("idSesion");
        se.eliminarSesion();
     
    }
    
}
