package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Evento;
import negocio.modelos.Sesion;

public class ControladorCUInformeEvento {

    public int plazasOfertadas(int idEvento, ArrayList<Sesion> sesionevento) {
        int plazasOfertadas = 0;
        for(Sesion s : sesionevento){
            plazasOfertadas = plazasOfertadas + s.getCupoMaximo();
        }
        return plazasOfertadas;
    }

    public int numeroInscritos(int idEvento, ArrayList<Sesion> sesionevento) {
        int numeroInscritos = 0;
        for(Sesion s : sesionevento){
            numeroInscritos = numeroInscritos + s.dameInscritos();
        }
        return numeroInscritos;
    }

    public int numeroAsistentes(int idEvento, ArrayList<Sesion> sesionevento) {
        int numeroAsistentes = 0;
        for(Sesion s : sesionevento){
            numeroAsistentes = numeroAsistentes + s.dameAsistentes();
        }
        return numeroAsistentes;
    }

    public ArrayList<Evento> listaEventosPeriodo(Date fechaPrimera, Date fechaSegunda) {
        Evento ev = new Evento();
        ArrayList infoEvs = ev.listaEventosPeriodo(fechaPrimera,fechaSegunda);
        ArrayList<Evento> eventos = new ArrayList<>();    
        int i;
            for(i=0;i<infoEvs.size();i+=3){
                eventos.add(new Evento((int) infoEvs.get(i), infoEvs.get(i+1).toString(), null, 0, (Date)infoEvs.get(i+2),null,null,null,null,null,null,null,null));
            }
            return eventos;
    }
    
}
