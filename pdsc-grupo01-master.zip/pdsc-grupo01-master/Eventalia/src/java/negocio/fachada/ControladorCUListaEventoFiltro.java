package negocio.fachada;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Evento;


public class ControladorCUListaEventoFiltro {
    public ArrayList<Evento> muestraEventosFiltrados(String filtroRQ, String filtroEQ, String filtroTQ, int idUser) throws SQLException {
        Evento ev=new Evento();
        ArrayList infoEvs=ev.getListaEventosFiltrados(filtroRQ, filtroEQ,filtroTQ, idUser);
        ArrayList<Evento> eventos = new ArrayList<>();    
        int i;
            for(i=0;i<infoEvs.size();i+=5){
                eventos.add(new Evento((int) infoEvs.get(i), infoEvs.get(i+1).toString(), null, (int) infoEvs.get(i+4), (Date)infoEvs.get(i+2),(Time)infoEvs.get(i+3),null,null,null,null,null,null,null));
            }
            return eventos;
    }
}
