package negocio.fachada;

import javax.servlet.http.HttpSession;
import negocio.modelos.Sesion;
import negocio.modelos.Usuario;

public class ControladorCUInscripcionSesion {

    public void inscribirse(int idSesion, HttpSession ses) {
        Usuario u = (Usuario)ses.getAttribute("user");
        int idUsuario = u.getIdUsuario();
        Sesion se = new Sesion(idSesion,null, 0, null, null, null,0,null,null);
        se.inscripcionSesion(idUsuario);
    }
    
}
