package negocio.fachada;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import negocio.modelos.Evento;

public class ControladorCUAgregarPonentes {

    public void agregarPonentes(int idEvento, String[] seleccion) {
      System.out.println("CU Servlet");
        Evento ev = new Evento(idEvento,null, null, 0, null, null, null, null, null, null, null, null,null);
        ev.agregarPonenteEvento(seleccion);
    }
    
}
