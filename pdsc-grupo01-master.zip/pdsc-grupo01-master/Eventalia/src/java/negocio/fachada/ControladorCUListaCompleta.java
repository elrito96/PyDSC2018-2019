package negocio.fachada;

import java.util.ArrayList;
import javax.servlet.http.HttpSession;
import negocio.modelos.Sesion;
import negocio.modelos.Usuario;

public class ControladorCUListaCompleta {

    public ArrayList<Usuario> getListaCompleta() {
        
        Usuario u=new Usuario();
        ArrayList<Object> infoEvs=u.getListaCompleta();
        
        ArrayList<Usuario> usuarios = new ArrayList<>();    
        int i;
        for(i=0;i<infoEvs.size();i+=4){
            System.out.println(infoEvs.get(i)+" "+infoEvs.get(i+1)+" "+infoEvs.get(i+2)+" "+infoEvs.get(i+3));
            
            Usuario ur = new Usuario((int) infoEvs.get(i), infoEvs.get(i+1).toString(), infoEvs.get(i+2).toString(), (int) infoEvs.get(i+3), "","","",false);
            
            usuarios.add(ur);
        }
        System.out.println(usuarios.get(0));
        return usuarios;
    }
    
}
