package negocio.fachada;

import negocio.modelos.Evento;

public class ControladorCUAgregarOrganizadores {

    public void agregarOrganizadores(int idEvento, String[] seleccion) {
 
        Evento ev = new Evento(idEvento,null, null, 0, null, null, null, null, null, null, null, null,null);
        ev.agregarOrganizadorEvento(seleccion);
    }
    
}
