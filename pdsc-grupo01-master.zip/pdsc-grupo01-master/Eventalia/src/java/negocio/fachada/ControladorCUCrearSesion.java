package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import javax.servlet.http.HttpSession;
import negocio.modelos.Sesion;
import negocio.modelos.Usuario;

public class ControladorCUCrearSesion {

    public void crearSesion(String lugar, int cupMax, String comentario, Time horaInicioSesion, Time horaFinSesion,int idEvento) {
        Sesion se = new Sesion(0,lugar, cupMax, comentario, horaInicioSesion, horaFinSesion, idEvento,null,null);
        se.crearSesion();
    }
    
}
