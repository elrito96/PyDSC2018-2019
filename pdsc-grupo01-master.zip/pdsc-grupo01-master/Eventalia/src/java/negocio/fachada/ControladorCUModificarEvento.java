package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import negocio.modelos.Evento;

public class ControladorCUModificarEvento {

    public Evento modificarEvento(int idEvento, String nombre, String descripcion, int estado, Date fechaInicioEvento, Date fechaFinEvento, Time horaInicioEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion, String condiciones) {
        Evento e = new Evento(idEvento, nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion, condiciones);
        e.modificarEvento();
        return e;
    }
    
}
