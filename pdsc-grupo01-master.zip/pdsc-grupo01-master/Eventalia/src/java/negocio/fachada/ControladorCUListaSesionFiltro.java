package negocio.fachada;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Sesion;


public class ControladorCUListaSesionFiltro {
    public ArrayList<Sesion> muestraSesionesFiltradas(String filtroRQ, String filtroEQ, int idUser) throws SQLException {
        Sesion ev=new Sesion();
        ArrayList infoSes=ev.getListaSesionesFiltradas(filtroRQ, filtroEQ, idUser);
        ArrayList<Sesion> sesiones = new ArrayList<>();       
        int i;
              for(i=0;i<infoSes.size();i+=5){
                    sesiones.add(new Sesion((int)infoSes.get(i), infoSes.get(i+1).toString(), 0, null, (Time)infoSes.get(i+2),null,0,infoSes.get(i+3).toString(),(Date)infoSes.get(i+4)));
            }
            return sesiones;
    }
}
