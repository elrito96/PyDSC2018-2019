package negocio.fachada;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Usuario;


public class ControladorCUListaUsuarioFiltro {
    public ArrayList<Usuario> muestraUsuariosFiltrados(String filtroR, String filtroS, String filtroT,String filtroP, int idEvento) throws SQLException {
        Usuario us=new Usuario();
        ArrayList infoUs=us.getUsuariosFiltrados(filtroR, filtroS,filtroT,filtroP, idEvento);
        ArrayList<Usuario> usuarios = new ArrayList<>();    
        int i;
            for(i=0;i<infoUs.size();i+=5){
                usuarios.add(new Usuario((int) infoUs.get(i), infoUs.get(i+1).toString(), infoUs.get(i+2).toString(), (int) infoUs.get(i+3), infoUs.get(i+4).toString(),null,null,true));
            }
            return usuarios;
    }
}
