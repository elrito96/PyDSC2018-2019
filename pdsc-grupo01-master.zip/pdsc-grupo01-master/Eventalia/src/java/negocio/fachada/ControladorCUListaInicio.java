package negocio.fachada;

import negocio.modelos.Evento;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

public class ControladorCUListaInicio {
    
    public ArrayList<Evento> muestraProxEventos() throws SQLException {
        Evento ev=new Evento();
        ArrayList infoEvs=ev.getListaEventosProximos();
        ArrayList<Evento> eventos = new ArrayList<>();       
        int i;
              for(i=0;i<infoEvs.size();i+=3){
                    eventos.add(new Evento(0, infoEvs.get(i).toString(), null, 0, (Date)infoEvs.get(i+1),(Time)infoEvs.get(i+2),null,null,null,null,null,null,null));
            }
            return eventos;
    }
}