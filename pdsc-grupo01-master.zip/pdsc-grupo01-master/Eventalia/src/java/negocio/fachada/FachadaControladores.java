/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio.fachada;

import java.sql.Date;
import negocio.modelos.Evento;
import negocio.modelos.Sesion;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import negocio.modelos.Usuario;

public class FachadaControladores {

    private ControladorCUListaInicio cuInicio = new ControladorCUListaInicio();
    private ControladorCUIdentificarse cuIdentificarse = new ControladorCUIdentificarse();
    private ControladorCUCrearUsuario cuCrearUsuario = new ControladorCUCrearUsuario();
    private ControladorCUListaEventoFiltro cuListaEvFil = new ControladorCUListaEventoFiltro();
    private ControladorCUCrearEvento cuCrearEvento = new ControladorCUCrearEvento();
    private ControladorCUEventoConcreto cuEventoConcreto = new ControladorCUEventoConcreto();
    private ControladorCUListaSesionFiltro cuListaSeFil = new ControladorCUListaSesionFiltro();
    private ControladorCUOrganizacion cuOrganizacion = new ControladorCUOrganizacion();
    private ControladorCUCrearSesion cuCrearSesion = new ControladorCUCrearSesion();
    private ControladorCUModificarEvento cuModificarEvento = new ControladorCUModificarEvento();

    private ControladorCUCambiarEstado cuCambiarEstado = new ControladorCUCambiarEstado();
    private ControladorCURechazarCondicionEvento cuRechazarCondicionEvento = new ControladorCURechazarCondicionEvento();
    private ControladorCUSesionConcreta cuSesionConcreta = new ControladorCUSesionConcreta();
    private ControladorCUInscripcionSesion cuInscripcionSesion = new ControladorCUInscripcionSesion();
    private ControladorCUVerSesionesEvento cuVerSesionesEvento = new ControladorCUVerSesionesEvento();
    private ControladorCUEliminarSesion cuEliminarSesion = new ControladorCUEliminarSesion();
    private ControladorCUCancelarInscripcionSesion cuCancelarInscripcionSesion = new ControladorCUCancelarInscripcionSesion();

    private ControladorCUVerUsuariosEvento cuVerUsuariosEvento = new ControladorCUVerUsuariosEvento();
    private ControladorCUAgregarPonentes cuAgregarPonentes = new ControladorCUAgregarPonentes();
    private ControladorCUAgregarOrganizadores cuAgregarOrganizadores = new ControladorCUAgregarOrganizadores();

    private ControladorCUMostrarNotificacionesE cuMostrarNotificacionesE = new ControladorCUMostrarNotificacionesE();
    private ControladorCUContadorNotificacionesEvento cuContadorNotificacionesEvento = new ControladorCUContadorNotificacionesEvento();
    private ControladorCUVerNotificacionesE cuVerNotificacionesE = new ControladorCUVerNotificacionesE();

    private ControladorCUMostrarNotificacionesL cuMostrarNotificacionesL = new ControladorCUMostrarNotificacionesL();
    private ControladorCUContadorNotificacionesLista cuContadorNotificacionesLista = new ControladorCUContadorNotificacionesLista();
    private ControladorCUVerNotificacionesL cuVerNotificacionesL = new ControladorCUVerNotificacionesL();

    private ControladorCUEstaInscrito cuEstaInscrito = new ControladorCUEstaInscrito();
    private ControladorCUEsOrganizador cuEsOrganizador = new ControladorCUEsOrganizador();

    private ControladorCURegistrarAsistencia cuRegistrarAsistencia = new ControladorCURegistrarAsistencia();

    private ControladorCUListaUsuarioFiltro cuListaUsFil = new ControladorCUListaUsuarioFiltro();

    private ControladorCUInformeEvento cuInformeEvento = new ControladorCUInformeEvento();
    private ControladorCUInformeUsuario cuInformeUsuario = new ControladorCUInformeUsuario();
    
    private ControladorCUListaCompleta cuListaCompleta = new ControladorCUListaCompleta();
    
    
    public ArrayList<Sesion> muestraSesionesFiltradas(String filtroRQ, String filtroEQ, int idUser) throws SQLException {
        ArrayList<Sesion> sesiones = cuListaSeFil.muestraSesionesFiltradas(filtroRQ, filtroEQ, idUser);
        return sesiones;
    }

    public ArrayList<Evento> muestraEventosFiltrados(String filtroRQ, String filtroEQ, String filtroTQ, int idUser) throws SQLException {
        ArrayList<Evento> eventos = cuListaEvFil.muestraEventosFiltrados(filtroRQ, filtroEQ, filtroTQ, idUser);
        return eventos;
    }

    public ArrayList<Usuario> getlistaUsuariosFiltrados(String filtroR, String filtroS, String filtroT, String filtroP, int idEvento) throws SQLException {
        ArrayList<Usuario> usuarios = cuListaUsFil.muestraUsuariosFiltrados(filtroR, filtroS, filtroT, filtroP, idEvento);
        return usuarios;
    }

    public ArrayList<Evento> muestraProxEventos() throws SQLException {
        ArrayList<Evento> eventos = cuInicio.muestraProxEventos();
        return eventos;
    }

    public Usuario identificarse(String login, String password) {
        Usuario user = cuIdentificarse.identificarse(login, password);
        return user;
    }

    public void crearUsuario(String nombre, String apellidos, int tipoUsuario, String login, String correo, String password, Boolean administrador) {
        cuCrearUsuario.crearUsuario(nombre, apellidos, tipoUsuario, login, correo, password, administrador);
    }

    public boolean loginExists(String login) {
        return cuCrearUsuario.loginExists(login);
    }

    public boolean emailExists(String correo) {
        return cuCrearUsuario.emailExists(correo);
    }

    public void crearEvento(String nombre, String descripcion, Date fechaInicioEvento, Date fechaFinEvento, Time horaInicioEvento, Time horaFinEvento, HttpSession ses) {
        cuCrearEvento.crearEvento(nombre, descripcion, fechaInicioEvento, fechaFinEvento, horaInicioEvento, horaFinEvento, ses);
    }

    public Evento consultaEventoConcreto(String eventoSeleccionado) {
        return cuEventoConcreto.consultaEventoConcreto(eventoSeleccionado);
    }

    public boolean consultaOrganizador(int idUsuario, int idEvento) {
        return cuOrganizacion.consultaOrganizador(idUsuario, idEvento);
    }

    public void crearSesion(String lugar, int cupMax, String comentario, Time horaInicioSesion, Time horaFinSesion, int idEvento) {
        cuCrearSesion.crearSesion(lugar, cupMax, comentario, horaInicioSesion, horaFinSesion, idEvento);
    }

    public Usuario dameSesion(HttpServletRequest request) {
        return cuIdentificarse.dameSesion(request);

    }

    public Evento modificarEvento(int idEvento, String nombre, String descripcion, int estado, Date fechaInicioEvento, Date fechaFinEvento, Time horaInicioEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion, String condiciones) {
        return cuModificarEvento.modificarEvento(idEvento, nombre, descripcion, estado, fechaInicioEvento, fechaFinEvento, horaInicioEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion, condiciones);
    }

    public void cambiarEstado(int idEvento, int estado, String nombre) {
        cuCambiarEstado.cambiarEstado(idEvento, estado, nombre);
    }

    public void rechazarCondicionEvento(String condiciones, int idEvento, int estado, String nombre) {
        cuRechazarCondicionEvento.rechazarCondicionEvento(condiciones, idEvento, estado, nombre);
    }

    public Sesion consultaSesionConcreta(String sesionSeleccionada) {
        return cuSesionConcreta.consultaSesionConcreta(sesionSeleccionada);
    }

    public void inscribirse(int idSesion, HttpSession ses) {
        cuInscripcionSesion.inscribirse(idSesion, ses);
    }

    public ArrayList<Sesion> getSesionesEvento(int idEvento) {
        return cuVerSesionesEvento.getSesionevento(idEvento);
    }

    public void eliminaSesion(int idSesion) {
        cuEliminarSesion.eliminaSesion(idSesion);
    }

    public void cancelarInscripcion(int idSesion, HttpSession ses) {
        cuCancelarInscripcionSesion.calcelainscripcion(idSesion, ses);
    }

    public ArrayList<Usuario> verUsuariosEvento(String filtroE, int idEvento) {
        return cuVerUsuariosEvento.getUsuariosEvento(filtroE, idEvento);
    }

    public void agregarPonentes(int idEvento, String[] seleccion) {
        cuAgregarPonentes.agregarPonentes(idEvento, seleccion);
    }

    public void agregarOrganizadores(int idEvento, String[] seleccion) {
        cuAgregarOrganizadores.agregarOrganizadores(idEvento, seleccion);

    }

    public ArrayList<String> muestraNotificacionesEvento(int id) {
        return cuMostrarNotificacionesE.mostrarNotificaciones(id);
    }

    public int contadorNotifiacionesEvento(int idUsuario) {
        return cuContadorNotificacionesEvento.mostrarNotificaciones(idUsuario);
    }

    public void verNotificacionesE(int idUsuario) {
        cuVerNotificacionesE.verNotificacionesE(idUsuario);
    }

    public ArrayList<String> muestraNotificacionesLista(int id) {
        return cuMostrarNotificacionesL.mostrarNotificaciones(id);
    }

    public int contadorNotificacionesLista(int idUsuario) {
        return cuContadorNotificacionesLista.mostrarNotificaciones(idUsuario);
    }

    public void verNotificacionesL(int idUsuario) {
        cuVerNotificacionesL.verNotificacionesL(idUsuario);
    }

    public boolean estaInscrito(int idUsuario, int idSesion) {
        return cuEstaInscrito.estaInscrito(idUsuario, idSesion);

    }
    public boolean esOrganizador(int idUsuario, int idSesion) {
        return cuEsOrganizador.esOrganizador(idUsuario, idSesion);

    }

    public void registrarAsistencia(int idSesion, String[] seleccion) {
        cuRegistrarAsistencia.registrarAsistencia(idSesion, seleccion);

    }
    
        public int plazasOfertadas(int idEvento) {
        return cuInformeEvento.plazasOfertadas(idEvento, cuVerSesionesEvento.getSesionevento(idEvento));
    }

    public int numeroInscritos(int idEvento) {
        return cuInformeEvento.numeroInscritos(idEvento, cuVerSesionesEvento.getSesionevento(idEvento));
    }

    public int numeroAsistentes(int idEvento) {
        return cuInformeEvento.numeroAsistentes(idEvento, cuVerSesionesEvento.getSesionevento(idEvento));
    }

    public ArrayList<Evento> listaEventosPeriodo(Date fechaPrimera, Date fechaSegunda) {
        return cuInformeEvento.listaEventosPeriodo(fechaPrimera,fechaSegunda);
    }

    public ArrayList<Evento> dameEventosCreador(int idUsuario) {
        return cuInformeUsuario.dameEventosCreador(idUsuario);
    }

    public ArrayList<Evento> dameEventosOrganizador(int idUsuario) {
        return cuInformeUsuario.dameEventosOrganizador(idUsuario);
    }

    public ArrayList<Evento> dameEventosPonente(int idUsuario) {
        return cuInformeUsuario.dameEventosPonente(idUsuario);
    }

    public ArrayList<Evento> dameEventosInscrito(int idUsuario) {
        return cuInformeUsuario.dameEventosInscrito(idUsuario);
    }

    public ArrayList<Evento> dameEventosAsistido(int idUsuario) {
        return cuInformeUsuario.dameEventosAsistido(idUsuario);
    }

    public ArrayList<Usuario> listaCompletaU() {
        return cuListaCompleta.getListaCompleta();
    }
}
