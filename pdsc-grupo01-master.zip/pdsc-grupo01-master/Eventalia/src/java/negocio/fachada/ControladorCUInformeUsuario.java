package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;

public class ControladorCUInformeUsuario {
    
    public ArrayList<Evento> dameEventosCreador(int idUsuario) {
        Evento ev=new Evento();
        ArrayList infoEvs = ev.dameEventosCreador(idUsuario);
        return auxiliar(infoEvs);
    }

    public ArrayList<Evento> dameEventosOrganizador(int idUsuario) {
        Evento ev=new Evento();
        ArrayList infoEvs = ev.dameEventosOrganizador(idUsuario);
        return auxiliar(infoEvs);
    }

    public ArrayList<Evento> dameEventosPonente(int idUsuario) {
        Evento ev=new Evento();
        ArrayList infoEvs = ev.dameEventosPonente(idUsuario);
        return auxiliar(infoEvs);
    }

    public ArrayList<Evento> dameEventosInscrito(int idUsuario) {
        Evento ev=new Evento();
        ArrayList infoEvs = ev.dameEventosInscrito(idUsuario);
        return auxiliar(infoEvs);
    }

    public ArrayList<Evento> dameEventosAsistido(int idUsuario) {
        Evento ev=new Evento();
        ArrayList infoEvs = ev.dameEventosAsistido(idUsuario);
        return auxiliar(infoEvs);
    }

    private ArrayList<Evento> auxiliar(ArrayList infoEvs) {
        ArrayList<Evento> eventos = new ArrayList<>();    
        int i;
        for(i=0;i<infoEvs.size();i+=4){
            eventos.add(new Evento((int) infoEvs.get(i), infoEvs.get(i+1).toString(), null, 0, (Date)infoEvs.get(i+2),(Time)infoEvs.get(i+3),null,null,null,null,null,null,null));
        }
        return eventos;
    }

    
}
