package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import javax.servlet.http.HttpSession;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;

public class ControladorCUCrearEvento {

    public void crearEvento(String nombre, String descripcion, Date fechaInicioEvento, Date fechaFinEvento, Time horaInicioEvento, Time horaFinEvento, HttpSession ses) {
        Usuario u = (Usuario)ses.getAttribute("user");
        int idUsuario = u.getIdUsuario();
        Evento ev = new Evento(0,nombre, descripcion, 0, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, null, null, null, null,null);
        ev.crearEvento(idUsuario);
    }
    
}
