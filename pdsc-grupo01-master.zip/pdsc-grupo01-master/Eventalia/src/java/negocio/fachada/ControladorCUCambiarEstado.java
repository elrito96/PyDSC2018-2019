package negocio.fachada;

import negocio.modelos.Evento;

public class ControladorCUCambiarEstado {

    public void cambiarEstado(int idEvento, int estado, String nombre) {
        Evento ev = new Evento();
        ev.setIdEvento(idEvento);
        ev.setEstado(estado);
        ev.setNombre(nombre);
        ev.cambiarEstado();
        
    }
    
}
