package negocio.fachada;

import negocio.modelos.Evento;
import negocio.modelos.Usuario;

public class ControladorCUOrganizacion {

    public boolean consultaOrganizador(int idUsuario, int idEvento) {
        Usuario u = new Usuario();
        u.setIdUsuario(idUsuario);
        return u.consultaOrganizador(idEvento);
    }
    
}
