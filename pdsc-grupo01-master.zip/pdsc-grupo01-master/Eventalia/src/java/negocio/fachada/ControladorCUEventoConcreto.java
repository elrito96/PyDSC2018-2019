package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Evento;

public class ControladorCUEventoConcreto {

    public Evento consultaEventoConcreto(String eventoSeleccionado) {
        Evento ev = new Evento();
        ev.setIdEvento(Integer.parseInt(eventoSeleccionado));
        ArrayList<Object> ec = ev.consultaEventoConcreto();
        ev.setIdEvento((int) ec.get(0));
        ev.setNombre(ec.get(1).toString());
        ev.setDescripcion(ec.get(2).toString());
        ev.setEstado((int) ec.get(3));
        ev.setFechaInicioEvento((Date) ec.get(4));
        ev.setHoraInicioEvento((Time) ec.get(5));
        ev.setFechaFinEvento((Date) ec.get(6));
        ev.setHoraFinEvento((Time) ec.get(7));
        ev.setFechaAperturaInscripcion((Date) ec.get(8));
        ev.setFechaCierreInscripcion((Date) ec.get(9));
        ev.setHoraAperturaInscripcion((Time) ec.get(10));
        ev.setHoraCierreInscripcion((Time) ec.get(11));
        return ev;
    }
    
}
