package negocio.fachada;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import negocio.modelos.Usuario;

public class ControladorCUIdentificarse {

    public Usuario identificarse(String login, String password) {
        Usuario user = new Usuario();
        user.setLogin(login);
        user.setPassword(password);
        user.identificarse();
        return user;
    }

    public Usuario dameSesion(HttpServletRequest request) {
        return (Usuario) request.getSession().getAttribute("user");
    }
    
}
