package negocio.fachada;

import java.sql.Time;
import java.util.ArrayList;
import negocio.modelos.Sesion;

public class ControladorCUSesionConcreta {

    public Sesion consultaSesionConcreta(String sesionSeleccionada) {
        Sesion se = new Sesion();
        se.setIdSesion(Integer.parseInt(sesionSeleccionada));
        ArrayList<Object> ec = se.consultaSesionConcreta();
        se.setIdSesion((int) ec.get(0));
        se.setLugar(ec.get(1).toString());
        se.setCupoMaximo((int)ec.get(2));
        se.setComentario(ec.get(3).toString());      
        se.setHoraInicioSesion((Time) ec.get(4));      
        se.setHoraFinalSesion((Time) ec.get(5));      
        se.setIdEvento((int) ec.get(6));
        return se;
    }
    
}
