package negocio.fachada;

import java.sql.Date;
import java.sql.Time;
import javax.servlet.http.HttpSession;
import negocio.modelos.Sesion;
import negocio.modelos.Usuario;

public class ControladorCUCancelarInscripcionSesion {

    public void calcelainscripcion(int idSesion, HttpSession ses) {
        Usuario u = (Usuario)ses.getAttribute("user");
        int idUsuario = u.getIdUsuario();
        Sesion se = new Sesion(idSesion,null, 0, null, null, null,0,null,null);
        se.cancelarInscripcionSesion(idUsuario);
    }
    
}
