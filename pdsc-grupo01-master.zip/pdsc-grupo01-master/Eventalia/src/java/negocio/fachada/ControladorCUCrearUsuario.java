package negocio.fachada;

import negocio.modelos.Usuario;

public class ControladorCUCrearUsuario {
    
    public void crearUsuario(String nombre, String apellidos, int tipoUsuario, String login, String correo, String password, Boolean administrador) {
        Usuario user = new Usuario(0,nombre,apellidos,tipoUsuario,login,correo,password, administrador);
        user.crearUsuario();
    }

    public boolean loginExists(String login) {
        Usuario user = new Usuario();
        user.setLogin(login);
        return user.loginExists();
    }

    public boolean emailExists(String correo) {
        Usuario user = new Usuario();
        user.setCorreo(correo);
        return user.emailExists();
    }
}