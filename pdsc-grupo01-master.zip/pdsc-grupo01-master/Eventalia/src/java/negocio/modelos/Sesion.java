package negocio.modelos;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import persistencia.fachada.FachadaDB;

public class Sesion implements Serializable {

    private int idSesion;
    private String lugar;
    private int cupoMaximo;
    private String comentario;
    private Time horaInicioSesion;
    private Time horaFinalSesion;
    private int idEvento;
    private String nombreEvento;
    private Date fechaInicioEvento;

    public Sesion() {
        idSesion = 0;
        lugar = "";
        cupoMaximo = 0;
        comentario = "";
        horaInicioSesion = null;
        horaFinalSesion = null;
        idEvento = 0;
        nombreEvento = "";
        fechaInicioEvento = null;
    }

    public Sesion(int idSesion, String lugar, int cupoMaximo, String comentario, Time horaInicioSesion, Time horaFinalSesion, int idEvento, String nombreEvento, Date fechaInicioEvento) {
        this.idSesion = idSesion;
        this.lugar = lugar;
        this.cupoMaximo = cupoMaximo;
        this.comentario = comentario;
        this.horaInicioSesion = horaInicioSesion;
        this.horaFinalSesion = horaFinalSesion;
        this.idEvento = idEvento;
        this.nombreEvento = nombreEvento;
        this.fechaInicioEvento = fechaInicioEvento;
    }

    /* public ArrayList <Object> getListaEventosProximos(){
        FachadaDB fachada=new FachadaDB();
        ArrayList infoEvs=fachada.getEventosProximos();
        return infoEvs;
    }*/
    public ArrayList<Object> getListaSesionesFiltradas(String filtroRQ, String filtroEQ, int idUser) {
        FachadaDB fachada = new FachadaDB();
        ArrayList infoSes = fachada.getSesionesFiltradas(filtroRQ, filtroEQ, idUser);
        return infoSes;
    }

    /* public void crearEvento(int idCreador) {
        FachadaDB fachada = new FachadaDB();
        fachada.insertarEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion);
        idEvento = fachada.selectIdEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento);
        if(idEvento!=0){
            fachada.insertarCreadorEvento(idCreador,idEvento);
            fachada.insertarOrganizadorEvento(idCreador, idEvento);
        }
    }*/
    public int getIdSesion() {
        return idSesion;
    }

    public void setIdSesion(int idsesion) {
        this.idSesion = idsesion;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public int getCupoMaximo() {
        return cupoMaximo;
    }

    public void setCupoMaximo(int cupoMaximo) {
        this.cupoMaximo = cupoMaximo;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Time getHoraInicioSesion() {
        return horaInicioSesion;
    }

    public void setHoraInicioSesion(Time horaInicioSesion) {
        this.horaInicioSesion = horaInicioSesion;
    }

    public Time getHoraFinalSesion() {
        return horaFinalSesion;
    }

    public void setHoraFinalSesion(Time horaFinalSesion) {
        this.horaFinalSesion = horaFinalSesion;
    }

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNombreEvento() {
        return nombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        this.nombreEvento = nombreEvento;
    }

    public Date getFechaInicioEvento() {
        return fechaInicioEvento;
    }

    public void setFechaInicioEvento(Date fechaInicioEvento) {
        this.fechaInicioEvento = fechaInicioEvento;
    }

    public void crearSesion() {
        FachadaDB fachada = new FachadaDB();
        fachada.insertarSesion(lugar, cupoMaximo, comentario, horaInicioSesion, horaFinalSesion, idEvento);
    }

    public ArrayList<Object> consultaSesionConcreta() {
        FachadaDB fachada = new FachadaDB();
        return fachada.consultaSesionConcreta(idSesion);
    }

    public void inscripcionSesion(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        fachada.inscripcionSesion(idSesion, idUsuario);
    }

    public ArrayList<Object> getListaSesionesEvento(int idEvento) {
        FachadaDB fachada = new FachadaDB();
        return fachada.getListaSesionesEvento(idEvento);
    }

    public void eliminarSesion() {
        FachadaDB fachada = new FachadaDB();
        fachada.eliminarSesion(idSesion);
    }

    public void cancelarInscripcionSesion(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        fachada.cancelarInscripcionSesion(idSesion, idUsuario);
        // 1 saber el cupo maximo = cm de esta sesion
        ArrayList<Object> infSesion = fachada.consultaSesionConcreta(idSesion);
        int cm = (int)infSesion.get(2)-1;
        lugar = (String)infSesion.get(1);
        // int 2 peticion para conocer si hay idusuario en la posicion cp
        Integer idNuevoInscrito = fachada.getUsuarioPosicionInscritoSesion(idSesion, cm);
        
        if(idNuevoInscrito!=null){
            
            int idEvento = (int)infSesion.get(6);
            nombreEvento = (String)fachada.consultaEventoConcreto(idEvento).get(1);
            String notificacion = escribeNotificacion(nombreEvento);
            fachada.addNotificacionL(idNuevoInscrito, idSesion, notificacion, 0);           
        }
      
    }
    String escribeNotificacion(String nombreEvento){
        return("Has pasado de la lista de espera a la lista de inscritos en la sesion en el lugar "+lugar+" con ID "+idSesion+" del evento "+nombreEvento);
    }

    public void registraAsistenciaSesion(String[] seleccion) {
        FachadaDB fachada = new FachadaDB();
        fachada.registraAsistencia(idSesion, seleccion);
    }
    public int dameAsistentes() {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameAsistentes(idSesion);
    }
    public int dameInscritos() {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameInscritos(idSesion);
    }
}
