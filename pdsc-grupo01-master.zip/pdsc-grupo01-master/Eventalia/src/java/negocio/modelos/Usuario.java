package negocio.modelos;


import persistencia.fachada.FachadaDB;
import java.io.Serializable;
import java.util.ArrayList;

public class Usuario implements Serializable {
    private int idUsuario;
    private String nombre;
    private String apellidos;
    private int tipoUsuario;
    private String login;
    private String correo;
    private String password;
    private boolean administrador;
    
    public Usuario() {
        idUsuario = 0;
        nombre = "";
        apellidos = "";
        tipoUsuario = 0;
        login = "";
        correo = "";
        password = "";
        administrador=false;
    }

    public Usuario(int idUsuario,String nombre, String apellidos, int tipoUsuario, String login, String correo, String password, Boolean administrador) {
        this.idUsuario=idUsuario;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.tipoUsuario=tipoUsuario;
        this.login=login;
        this.correo=correo;
        this.password=password;
        this.administrador=administrador;
    }

   /* public Usuario(int id, String nombre, String apellidos, String tipoUsuario, String login, String correo, String password) {
        this.id = id;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.tipoUsuario=tipoUsuario;
        this.login=login;
        this.correo=correo;
        this.password=password;
    }*/
    
    public boolean isAdministrador() {
        return administrador;
    }

    public void crearUsuario() {
        FachadaDB fachada = new FachadaDB();
        fachada.insertarUsuario(nombre, apellidos, tipoUsuario, login, correo, password, administrador);
    }
    
    public boolean loginExists() {
        FachadaDB fachada = new FachadaDB();
        return fachada.loginExists(login);
    }
    
    public boolean emailExists() {
        FachadaDB fachada = new FachadaDB();
        return fachada.emailExists(correo);
    }
    
    public void identificarse() {
        FachadaDB fachada = new FachadaDB();
        ArrayList aux = fachada.identificarse(login,password);
        if(!aux.isEmpty()){
            idUsuario = (int) aux.get(0);
            nombre = (String) aux.get(1);
            apellidos = (String) aux.get(2);
            tipoUsuario = (int) aux.get(3);
            login = (String) aux.get(4);
            correo = (String) aux.get(5);
            password = (String) aux.get(6);
            administrador = auxiliar((Integer)aux.get(7));
        }
    }
    
    private boolean auxiliar(int a){
        if(a == 0){
            return false;
        }else{
            return true;
        }
    }
    public boolean consultaOrganizador(int idEvento) {
        FachadaDB fachada = new FachadaDB();
        return fachada.consultaOrganizador(idUsuario, idEvento);
    }
    
    
    

    public int getIdUsuario() {
        return idUsuario;
    }
    
    public void setIdUsuario(int id) {
        this.idUsuario = id;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(int tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
   
    public boolean getAdministrador() {
        return administrador;
    }

    public void setAdministrador(boolean administrador) {
        this.administrador = administrador;
    }
    
    public ArrayList<Object> getListaUsuariosFiltrados( String filtroE, int idEvento) {
        FachadaDB fachada = new FachadaDB();
        ArrayList users = fachada.getUsuariosFiltrados( filtroE, idEvento);
        return users;
    }
    
    public ArrayList<Object> getUsuariosFiltrados( String filtroR, String filtroS, String filtroT,String filtroP, int idEvento) {
        FachadaDB fachada = new FachadaDB();
        ArrayList users = fachada.getListaUsuariosFiltrados( filtroR, filtroS,filtroT,filtroP, idEvento);
        return users;
    }
    public ArrayList<String> getListaNotificacionesEventos(){
        FachadaDB fachada=new FachadaDB();
        
        ArrayList<String> notifEvs=fachada.getNotificacionesEventos(idUsuario);
        return notifEvs;
    }
    public int getContadorNotificacionesE(){
        FachadaDB fachada=new FachadaDB();
        int contador = fachada.getContadorNotificaciones(idUsuario);
        return contador;
    }
    public void verNotificacionesE(){
        FachadaDB fachada=new FachadaDB();
        fachada.verNotificacionesE(idUsuario);
    }
    public ArrayList<String> getListaNotificacionesLista(){
        FachadaDB fachada=new FachadaDB();
        
        ArrayList<String> notifEvs=fachada.getNotificacionesLista(idUsuario);
        return notifEvs;
    }
    public int getContadorNotificacionesL(){
        FachadaDB fachada=new FachadaDB();
        int contador = fachada.getContadorNotificacionesL(idUsuario);
        return contador;
    }
    public void verNotificacionesL(){
        FachadaDB fachada=new FachadaDB();
        fachada.verNotificacionesL(idUsuario);
    }
    public boolean estaInscrito(int idSesion){
        FachadaDB fachada=new FachadaDB();
        return fachada.estaInscrito(idUsuario,idSesion);
    }
    public boolean esOrganizador(int idSesion){
        FachadaDB fachada=new FachadaDB();
        System.out.println(idSesion);
        ArrayList<Object> infSesion = fachada.consultaSesionConcreta(idSesion);
        int idEvento = (int)infSesion.get(6);
        return fachada.esOrganizador(idUsuario,idEvento);
    }

    public ArrayList<Object> getListaCompleta() {
        FachadaDB fachada=new FachadaDB();
        ArrayList users = fachada.geListaCompleta();
        return users;
    }
    
}