package negocio.modelos;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import persistencia.fachada.FachadaDB;

public class Evento implements Serializable{
    private int idEvento;
    private String nombre;
    private String descripcion;
    private int estado;
    //enum estado;
    private Date fechaInicioEvento;
    private Time horaInicioEvento;
    private Date fechaFinEvento;
    private Time horaFinEvento;
    private Date fechaAperturaInscripcion;
    private Date fechaCierreInscripcion;
    private Time horaAperturaInscripcion;
    private Time horaCierreInscripcion;
    private String condiciones;

    public Evento(){
        idEvento=0;
        nombre="";
        descripcion = "";
        estado = 0;
        //estado='loquesea'
        fechaInicioEvento=null;
        horaInicioEvento=null;
        fechaFinEvento=null;
        horaFinEvento=null;
        fechaAperturaInscripcion = null;
        fechaCierreInscripcion = null;
        horaAperturaInscripcion = null;
        horaCierreInscripcion = null;
        condiciones = "";
    }
    
    public Evento(int idEvento, String nombre, String descripcion, int estado,Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento,  Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion, String condiciones){
        this.idEvento = idEvento;
        this.nombre=nombre;
        this.descripcion = descripcion;
        this.estado = estado;
        this.fechaInicioEvento=fechaInicioEvento;
        this.horaInicioEvento=horaInicioEvento;
        this.fechaFinEvento=fechaFinEvento;
        this.horaFinEvento=horaFinEvento;
        this.fechaAperturaInscripcion = fechaAperturaInscripcion;
        this.fechaCierreInscripcion = fechaCierreInscripcion;
        this.horaAperturaInscripcion = horaAperturaInscripcion;
        this.horaCierreInscripcion = horaCierreInscripcion;
        this.condiciones = condiciones;
    }

    public ArrayList <Object> getListaEventosProximos(){
        FachadaDB fachada=new FachadaDB();
        ArrayList infoEvs=fachada.getEventosProximos();
        return infoEvs;
    }
    
    public void agregarPonenteEvento(String[] seleccion){
        FachadaDB fachada = new FachadaDB();
        fachada.agregarPonenteEvento(idEvento,seleccion);
    }
    
    public void agregarOrganizadorEvento(String[] seleccion){
        FachadaDB fachada = new FachadaDB();
        fachada.agregarOrganizadorEvento(idEvento,seleccion);
    }

     public ArrayList <Object> getListaEventosFiltrados(String filtroRQ, String filtroEQ, String filtroTQ, int idUser){
        FachadaDB fachada=new FachadaDB();
        ArrayList infoEvs=fachada.getEventosFiltrados(filtroRQ, filtroEQ,filtroTQ, idUser);
        return infoEvs;
    }
     
    public void crearEvento(int idCreador) {
        FachadaDB fachada = new FachadaDB();
        fachada.insertarEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion);
        idEvento = fachada.selectIdEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento);
        if(idEvento!=0){
            fachada.insertarCreadorEvento(idCreador,idEvento);
            fachada.insertarOrganizadorEvento(idCreador, idEvento);
        }
    }
    
    public ArrayList<Object> consultaEventoConcreto() {
        FachadaDB fachada = new FachadaDB();
        return fachada.consultaEventoConcreto(idEvento);
    }
     
    
    public void modificarEvento() {
        FachadaDB fachada = new FachadaDB();
        fachada.modificarEvento(idEvento, nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion,condiciones);
    }
    
    public void cambiarEstado(){
        FachadaDB fachada = new FachadaDB();
        String notificacion = escribeNotificacion();
        fachada.cambiarEstado(idEvento,estado);
        //get id creador del evento
        int idCreador = fachada.getIdCreador(idEvento);
        fachada.addNotificacionE(idCreador, idEvento, notificacion, 0);    
    }
    public String escribeNotificacion(){
        String notificacion = "";
        if(estado==3){
            notificacion = "Tu evento "+nombre+" ha sido rechazado condicionalmente, a no ser que resuelvas los conflictos: "+condiciones;
        }else if(estado==1){
            notificacion = "Tu evento "+nombre+" ha sido aprobado";
        }else if(estado==2){
            notificacion = "Tu evento "+nombre+" ha sido rechazado";
        }
        return notificacion;
    }

    public void rechazarCondicionEvento() {
        FachadaDB fachada = new FachadaDB();
        String notificacion = escribeNotificacion();
        fachada.cambiarEstado(idEvento,estado);
        fachada.rechazarCondicionEvento(condiciones, idEvento);
        int idCreador = fachada.getIdCreador(idEvento);
        fachada.addNotificacionE(idCreador, idEvento, notificacion, 0);
    }
    public ArrayList<Object> listaEventosPeriodo(Date fechaPrimera, Date fechaSegunda) {
        FachadaDB fachada = new FachadaDB();
        return fachada.listaEventosPeriodo(fechaPrimera,fechaSegunda);
    }
    
    public ArrayList<Object> dameEventosCreador(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameEventosCreador(idUsuario);
    }

    public ArrayList<Object> dameEventosOrganizador(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameEventosOrganizador(idUsuario);
    }

    public ArrayList<Object> dameEventosPonente(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameEventosPonente(idUsuario);
    }

    public ArrayList<Object> dameEventosInscrito(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameEventosInscrito(idUsuario);
    }

    public ArrayList<Object> dameEventosAsistido(int idUsuario) {
        FachadaDB fachada = new FachadaDB();
        return fachada.dameEventosAsistido(idUsuario);
    }
    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Date getFechaAperturaInscripcion() {
        return fechaAperturaInscripcion;
    }

    public void setFechaAperturaInscripcion(Date fechayHoraAperturaInscripcion) {
        this.fechaAperturaInscripcion = fechayHoraAperturaInscripcion;
    }

    public Date getFechaCierreInscripcion() {
        return fechaCierreInscripcion;
    }

    public void setFechaCierreInscripcion(Date fechayHoraCierreInscripcion) {
        this.fechaCierreInscripcion = fechayHoraCierreInscripcion;
    }

    public Time getHoraAperturaInscripcion() {
        return horaAperturaInscripcion;
    }

    public void setHoraAperturaInscripcion(Time horaAperturaInscripcion) {
        this.horaAperturaInscripcion = horaAperturaInscripcion;
    }

    public Time getHoraCierreInscripcion() {
        return horaCierreInscripcion;
    }

    public void setHoraCierreInscripcion(Time horaCierreInscripcion) {
        this.horaCierreInscripcion = horaCierreInscripcion;
    }

    public Date getFechaInicioEvento() {
        return fechaInicioEvento;
    }

    public void setFechaInicioEvento(Date fechaInicioEvento) {
        this.fechaInicioEvento = fechaInicioEvento;
    }

    public Time getHoraInicioEvento() {
        return horaInicioEvento;
    }

    public void setHoraInicioEvento(Time horaInicioEvento) {
        this.horaInicioEvento = horaInicioEvento;
    }

    public Date getFechaFinEvento() {
        return fechaFinEvento;
    }

    public void setFechaFinEvento(Date fechaFinEvento) {
        this.fechaFinEvento = fechaFinEvento;
    }

    public Time getHoraFinEvento() {
        return horaFinEvento;
    }

    public void setHoraFinEvento(Time horaFinEvento) {
        this.horaFinEvento = horaFinEvento;
    }
    
    public String getCondiciones() {
        return condiciones;
    }

    public void setCondiciones(String condiciones) {
        this.condiciones = condiciones;
    }
    
}
