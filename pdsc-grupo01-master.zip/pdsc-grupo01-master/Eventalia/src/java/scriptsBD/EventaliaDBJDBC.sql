
DROP TABLE Inscripcion;
DROP TABLE Ponencia;
DROP TABLE Creacion;
DROP TABLE Asistencia;
DROP TABLE Organizacion;

DROP TABLE NotificacionesE;
DROP TABLE NotificacionesL;

DROP TABLE Sesion;
DROP TABLE Evento;
DROP TABLE Usuario;


/* tipo usuario 0 alumno, 1 pdi, 2 pas*/

CREATE TABLE Usuario (
idUsuario INT not null primary key
       
       AUTO_INCREMENT,
nombre VARCHAR(50),
apellidos VARCHAR(100),
tipoUsuario INT NOT NULL,
login VARCHAR(20),
correo VARCHAR(100),
password VARCHAR(20),
administrador INT NOT NULL
);

/* Estado 0 pendinte, 1 aceptado, 2 rechazado, 3 rechazado condicionalmente*/

CREATE TABLE Evento (
idEvento INT not null primary key
       
       AUTO_INCREMENT,
nombre VARCHAR(50),
descripcion VARCHAR(500),
estado INT NOT NULL,
fechaInicioEvento DATE NOT NULL,
horaInicioEvento TIME NOT NULL,
fechaFinEvento DATE NOT NULL,
horaFinEvento TIME NOT NULL,
fechaAperturaInscripcion DATE,
fechaCierreInscripcion DATE,
horaAperturaInscripcion TIME,
horaCierreInscripcion TIME,
condiciones VARCHAR(500)
);


CREATE TABLE Organizacion (
idUsuario INT NOT NULL,
idEvento INT NOT NULL
);

ALTER TABLE Organizacion ADD CONSTRAINT PK_Organizacion PRIMARY KEY (idUsuario,idEvento);


CREATE TABLE Sesion (
idSesion INT not null primary key
       
       AUTO_INCREMENT,
lugar VARCHAR(150),
cupoMaximo INT,
comentario VARCHAR(500),
horaInicioSesion TIME NOT NULL,
horaFInalSesion TIME NOT NULL,
idEvento INT NOT NULL
);

CREATE TABLE Asistencia (
idSesion INT NOT NULL,
idUsuario INT NOT NULL
);

ALTER TABLE Asistencia ADD CONSTRAINT PK_Asistencia PRIMARY KEY (idSesion,idUsuario);


CREATE TABLE Creacion (
idUsuario INT NOT NULL,
idEvento INT NOT NULL
);

ALTER TABLE Creacion ADD CONSTRAINT PK_Creacion PRIMARY KEY (idUsuario,idEvento);

CREATE TABLE Inscripcion (
idUsuario INT NOT NULL,
idSesion INT NOT NULL,
posicionEspera INT NOT NULL
);

CREATE TABLE Ponencia (
idUsuario INT NOT NULL,
idEvento INT NOT NULL
);

CREATE TABLE NotificacionesE (
idUsuario INT NOT NULL,
idEvento INT NOT NULL,
notificacion VARCHAR(500),
visto INT NOT NULL
);

CREATE TABLE NotificacionesL (
idUsuario INT NOT NULL,
idSesion INT NOT NULL,
notificacion VARCHAR(500),
visto INT NOT NULL
);

ALTER TABLE NotificacionesE ADD CONSTRAINT PFK_NotificacionE_0 PRIMARY KEY (idUsuario,idEvento);
ALTER TABLE NotificacionesL ADD CONSTRAINT FK_NotificacionL_01 PRIMARY KEY (idUsuario,idSesion);

ALTER TABLE NotificacionesE ADD CONSTRAINT FK_NotificacionE_0 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);
ALTER TABLE NotificacionesE ADD CONSTRAINT FK_NotificacionE_1 FOREIGN KEY (idEvento) REFERENCES Evento (idEvento);

ALTER TABLE NotificacionesL ADD CONSTRAINT FK_NotificacionL_0 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);
ALTER TABLE NotificacionesL ADD CONSTRAINT FK_NotificacionL_1 FOREIGN KEY (idSesion) REFERENCES Sesion (idSesion);

ALTER TABLE Ponencia ADD CONSTRAINT PK_Ponencia PRIMARY KEY (idUsuario,idEvento);

ALTER TABLE Inscripcion ADD CONSTRAINT PK_Inscripcion PRIMARY KEY (idSesion,idUsuario);


ALTER TABLE Organizacion ADD CONSTRAINT FK_Organizacion_0 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);
ALTER TABLE Organizacion ADD CONSTRAINT FK_Organizacion_1 FOREIGN KEY (idEvento) REFERENCES Evento (idEvento);


ALTER TABLE Sesion ADD CONSTRAINT FK_Sesion_0 FOREIGN KEY (idEvento) REFERENCES Evento (idEvento);


ALTER TABLE Asistencia ADD CONSTRAINT FK_Asistencia_0 FOREIGN KEY (idSesion) REFERENCES Sesion (idSesion);
ALTER TABLE Asistencia ADD CONSTRAINT FK_Asistencia_1 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);


ALTER TABLE Creacion ADD CONSTRAINT FK_Creacion_0 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);
ALTER TABLE Creacion ADD CONSTRAINT FK_Creacion_1 FOREIGN KEY (idEvento) REFERENCES Evento (idEvento);

ALTER TABLE Inscripcion ADD CONSTRAINT FK_Inscripcion_0 FOREIGN KEY (idSesion) REFERENCES Sesion (idSesion);
ALTER TABLE Inscripcion ADD CONSTRAINT FK_Inscripcion_1 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);

ALTER TABLE Ponencia ADD CONSTRAINT FK_Ponencia_0 FOREIGN KEY (idEvento) REFERENCES Evento (idEvento);
ALTER TABLE Ponencia ADD CONSTRAINT FK_Ponencia_1 FOREIGN KEY (idUsuario) REFERENCES Usuario (idUsuario);