INSERT INTO Usuario (nombre, apellidos, tipoUsuario, login, correo, password, administrador)
VALUES      ('Luis', 'Martinez de la Fuente', 0, 'luismar', 'luisito@hotmail.com', '1234',0),
            ('Marta', 'Gonzalez Bravo', 0, 'martita18', 'mar_Brav@hotmail.com', '1234',0),
            ('Carissa','Lynn',0,'Casey','ultric@lainterdum.edu','LQX25GSP0EO',0),
            ('Levi','Kelly',0,'Tarik','tempor.augue.ac@libero.co.uk','FQE83DZH0PW',0),
            ('Autumn','Simon',0,'Felicia','Etiam.ligula@Nulla.org','YKT15VYH2KM',0),
            ('Blaine','Owens',0,'Griffith','Donec@volutpat.net','VSS83BTH6ML',0),
            ('Aiko','Stark',0,'Miranda','nascetur.ridiculus@estconguea.net','IHU62ZPK3XA',0),
            ('Kitra','Dixon',0,'Hyacinth','iaculis.lacus.pede@vitaeorci.ca','YZV95VHK0ZV',0),
            ('Howard','Whitaker',0,'Freya','ante@dolordolortempus.net','BFQ89DXZ0FU',0),
            ('Vera','Skinner',0,'Lance','molestie@nonummy.net','NMA46IFP4QH',0),
            ('Caryn','Tyler',0,'Indigo','montes@lestie.net','ZNJ95XRZ0FZ',0),
            ('Abraham','Kelley',0,'Wayne','tristique@metus.org','DRK94SBQ0SN',0),
            ('Malachi','Macdonald',0,'Lewis','Suspendisse.tristique.neque@egetvolutpatornare.co.uk','YTV78WHQ0JG',0),
            ('Mechelle','Hardy',0,'Russell','sodales@dolor.co.uk','BGE07GDX8FS',0),
            ('Xenos','Avery',1,'Quinn','egestas.nunc@ultrices.org','LRV73HXD9AY',0),
            ('Randall','Salinas',1,'Lois','libero@pedeCumsociis.edu','UKB21DNT3ZM',0),
            ('Kelly','Baker',1,'Marsden','eget.metus.eu@fringillacursuspurus.edu','JEX40JAV0TQ',0),
            ('Mallory','Moreno',1,'Kyra','mauris.ut.mi@tellusloremeu.edu','OVK71ZHS6DH',0),
            ('Jin','Foster',1,'Olivia','Sed@etarcuimperdiet.net','MXA27CIC3FM',0),
            ('Shana','Valenzuela',1,'Justine','turpis.Aliquam@mus.org','WLL84MIJ5OV',0),
            ('Akeem','Sloan',2,'Rebekah','ultrices@a.co.uk','DHX89YXV2YE',0),
            ('Hop','Mathis',2,'Catherine','et@nullaInteger.co.uk','WAH61SMM4LG',0),
            ('Alvaro', 'Benito Navarro', 0, 'alvbeni', 'alvarito@hotmail.com', 'admin',1),
            ('Juan', 'Rodriguez Sanz', 0, 'juarodr', 'juanito@hotmail.com', 'admin',1),
            ('Carlos Ivan', 'Carravilla Ferreras', 0, 'carlcar', 'ivens@yahoo.es', 'admin',1),
            ('Adrian', 'Sanchez Fernandez', 0, 'adrsanc', 'adri@terra.es','admin',1);

INSERT INTO Evento (nombre, descripcion, estado , fechaInicioEvento , horaInicioEvento , fechaFinEvento , horaFinEvento , fechaAperturaInscripcion , fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion,condiciones)
VALUES      ('Evento Apertura','Evento de la apertura de la Universidad',3,'2019-05-04','08:00:00','2019-06-10','10:00:00',NULL,NULL,NULL,NULL,'Elige cualquier otro lugar'),
            ('La gran Charla','Una charla de 24 horas nonstop en la que se hablara de todo',1,'2010-11-11','00:00:01','2017-11-11','23:59:59',NULL,NULL,NULL,NULL,NULL),
            ('Charla Cultura','Una charla de 24 horas nonstop en la que se hablara de todo',1,'2019-11-11','00:00:01','2019-11-11','23:59:59',NULL,NULL,NULL,NULL,NULL),
            ('La prueba','Una charla de 24 horas nonstop en la que se hablara de todo',1,'2019-11-11','00:00:01','2019-11-11','23:59:59',NULL,NULL,NULL,NULL,NULL);

INSERT INTO Sesion (lugar, cupoMaximo, comentario, horaInicioSesion, horaFInalSesion, idEvento)
VALUES      ('Salon principal',30,'Chapa monumental','00:00:01','20:00:00',2),
            ('Salon de grados',30,'Chapa monumental2','00:00:01','20:00:00',2),
            ('Salon',30,'Chapa monumental3','00:00:01','20:00:00',2),
            ('Vota vox',30,'Intento de casa para pajaros1','00:00:01','20:00:00',3),
            ('Casa de pajer',30,'Otro','00:00:01','20:00:00',1),
            ('Aulario',30,'Chapa monumental2','00:00:01','20:00:00',4),
            ('Historia',30,'Monumentos','00:00:01','20:00:00',4);

INSERT INTO Creacion (idUsuario, idEvento)
VALUES      (1, 3),
            (2, 4),
            (23, 1),
            (24, 2);

INSERT INTO Organizacion (idUsuario, idEvento)
VALUES      (1, 3),
            (2, 4),
            (23, 1),
            (24, 1),
            (24, 2);

INSERT INTO Asistencia (idSesion, idUsuario)
VALUES      (1,23),
            (1,24),
            (2,23),
            (2,24);

INSERT INTO Inscripcion (idUsuario, idSesion, posicionEspera)
VALUES      (23,1,0),
            (24,1,0),
            (23,2,0),
            (24,2,0);

INSERT INTO Ponencia (idUsuario, idEvento)
VALUES      (4, 1),
            (1, 1),
            (2, 2),
            (2, 3),
            (5, 1);

INSERT INTO NotificacionesE (idUsuario, idEvento, notificacion,visto)
VALUES      (23, 1,'Tu evento Evento Apertura ha sido aceptado condicionalmente con condiciones de cambiar lugar' ,1);
            

