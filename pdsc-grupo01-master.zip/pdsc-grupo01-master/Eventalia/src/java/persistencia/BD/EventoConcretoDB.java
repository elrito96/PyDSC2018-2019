package persistencia.BD;

import serviciosComunes.ConnectionPool;
import java.sql.*;
import java.util.ArrayList;

public class EventoConcretoDB {
    
    public ArrayList<Object> consultaEventoConcreto(int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM Evento WHERE idEvento = ?";
        
        ArrayList<Object> ev = new ArrayList<Object>();
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1,idEvento);
            rs = ps.executeQuery(); 
            while (rs.next()) {
                ev.add(rs.getInt("idEvento"));
                ev.add(rs.getString("nombre"));
                ev.add(rs.getString("descripcion"));
                ev.add(rs.getInt("estado"));
                ev.add(rs.getDate("fechaInicioEvento"));
                ev.add(rs.getTime("horaInicioEvento"));
                ev.add(rs.getDate("fechaFinEvento"));
                ev.add(rs.getTime("horaFinEvento"));
                ev.add(rs.getDate("fechaAperturaInscripcion"));
                ev.add(rs.getDate("fechaCierreInscripcion"));
                ev.add(rs.getTime("horaAperturaInscripcion"));
                ev.add(rs.getTime("horaCierreInscripcion"));
                ev.add(rs.getString("condiciones"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ev;
    }
    
}
