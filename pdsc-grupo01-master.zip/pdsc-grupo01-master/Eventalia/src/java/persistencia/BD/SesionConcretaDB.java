package persistencia.BD;

import serviciosComunes.ConnectionPool;
import java.sql.*;
import java.util.ArrayList;

public class SesionConcretaDB {
    
    public ArrayList<Object> consultaSesionConcreta(int idSesion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM Sesion WHERE idSesion = ?";
        
        ArrayList<Object> se = new ArrayList<Object>();
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1,idSesion);
            rs = ps.executeQuery(); 
            while (rs.next()) {
                se.add(rs.getInt("idSesion"));
                se.add(rs.getString("lugar"));
                se.add(rs.getInt("cupomaximo"));
                se.add(rs.getString("comentario"));             
                se.add(rs.getTime("horaInicioSesion"));            
                se.add(rs.getTime("horaFinalSesion"));
                se.add(rs.getInt("idEvento"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return se;
    }
    
}
