/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import serviciosComunes.ConnectionPool;

/**
 *
 * @author Ivan
 */
public class AsistenciaDB {

    public void registraAsistencia(int idSesion, String[] seleccion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO Asistencia (idSesion, idUsuario) VALUES(?,?)";
        try {
            ps = connection.prepareStatement(query);
            for (String idUsuario : seleccion) {
                ps.setInt(1, idSesion);
                ps.setInt(2, Integer.parseInt(idUsuario));
                ps.executeUpdate();
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    public int dameAsistentes(int idSesion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int res = 0;
        try {
            ps = connection.prepareStatement("select COUNT(*) as numeroInscritos"
                        + " from Asistencia A"
                        + " WHERE A.idSesion =" + idSesion);
            rs = ps.executeQuery();
            while (rs.next()) {
                res = rs.getInt("numeroInscritos");
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }
}
