package persistencia.BD;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class InformeDB {

    public ArrayList<Object> listaEventosPeriodo(Date fechaPrimera, Date fechaSegunda) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento"
                    + " from Evento E"
                    + " WHERE E.ESTADO = 1 AND E.fechaFinEvento >'" + fechaPrimera + "' AND E.fechaFinEvento < '" + fechaSegunda + "'");
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

    public ArrayList<Object> dameEventosCreador(int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento, E.HORAINICIOEVENTO"
                    + " from Evento E, Creacion C"
                    + " WHERE E.idEvento = C.idEvento AND C.idUsuario =" + idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                  infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

    public ArrayList<Object> dameEventosOrganizador(int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento, E.HORAINICIOEVENTO"
                    + " from Evento E, Organizacion O"
                    + " WHERE E.idEvento = O.idEvento AND O.idUsuario =" + idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                  infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

    public ArrayList<Object> dameEventosPonente(int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento, E.HORAINICIOEVENTO"
                    + " from Evento E, Asistencia A, Sesion S"
                    + " WHERE E.idEvento = S.idEvento AND S.idSesion = A.idSesion AND A.idUsuario =" + idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                  infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

    public ArrayList<Object> dameEventosInscrito(int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento, E.HORAINICIOEVENTO"
                    + " from Evento E, Inscripcion I, Sesion S"
                    + " WHERE E.idEvento = S.idEvento AND S.idSesion = I.idSesion AND I.idUsuario =" + idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                  infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

    public ArrayList<Object> dameEventosAsistido(int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.idEvento, E.NOMBRE, E.fechaInicioEvento, E.HORAINICIOEVENTO"
                    + " from Evento E, Asistencia A, Sesion S"
                    + " WHERE E.idEvento = S.idEvento AND S.idSesion = A.idSesion  AND A.idUsuario =" + idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                  infoEvs.add(rs.getInt("idEvento"));
                  infoEvs.add(rs.getString("NOMBRE"));
                  infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                  infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }

}
