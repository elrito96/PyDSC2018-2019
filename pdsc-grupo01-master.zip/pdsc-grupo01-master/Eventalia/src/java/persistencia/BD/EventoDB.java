package persistencia.BD;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import serviciosComunes.ConnectionPool;

public class EventoDB {

    public void insertarEvento(String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO Evento (nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setString(2, descripcion);
            ps.setInt(3, estado);
            ps.setDate(4, fechaInicioEvento);
            ps.setTime(5, horaInicioEvento);
            ps.setDate(6, fechaFinEvento);
            ps.setTime(7, horaFinEvento);
            ps.setDate(8, fechaAperturaInscripcion);
            ps.setDate(9, fechaCierreInscripcion);
            ps.setTime(10, horaAperturaInscripcion);
            ps.setTime(11, horaCierreInscripcion);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public int selectIdEvento(String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT idEvento FROM Evento WHERE nombre = ? AND descripcion = ? AND estado = ? AND fechaInicioEvento = ? AND horaInicioEvento = ? AND fechaFinEvento = ? AND horaFinEvento = ? " ;
        int idEvento = 0;
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setString(2, descripcion);
            ps.setInt(3, estado);
            ps.setDate(4, fechaInicioEvento);
            ps.setTime(5, horaInicioEvento);
            ps.setDate(6, fechaFinEvento);
            ps.setTime(7, horaFinEvento);
            rs = ps.executeQuery();
            while(rs.next()){
                idEvento = rs.getInt("idEvento");
            }
            System.out.println(idEvento);
            ps.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();  
        } 
        
        pool.freeConnection(connection);
        
        return idEvento;
    }

    public void insertarCreadorEvento(int idCreador, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "INSERT INTO Creacion (idUsuario, idEvento) VALUES(?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idCreador);
            ps.setInt(2, idEvento);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public void insertarOrganizadorEvento(int idOrganizador, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "INSERT INTO Organizacion (idUsuario, idEvento) VALUES(?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idOrganizador);
            ps.setInt(2, idEvento);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public void modificarEvento(int idEvento, String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion, String condiciones) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Evento SET nombre = ?, descripcion = ?, estado = ?, fechaInicioEvento = ?, horaInicioEvento = ?, fechaFinEvento = ?, horaFinEvento = ?, fechaAperturaInscripcion = ?, fechaCierreInscripcion = ?, horaAperturaInscripcion = ?, horaCierreInscripcion = ?, condiciones = ? WHERE idEvento = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setString(2, descripcion);
            ps.setInt(3, estado);
            ps.setDate(4, fechaInicioEvento);
            ps.setTime(5, horaInicioEvento);
            ps.setDate(6, fechaFinEvento);
            ps.setTime(7, horaFinEvento);
            ps.setDate(8, fechaAperturaInscripcion);
            ps.setDate(9, fechaCierreInscripcion);
            ps.setTime(10, horaAperturaInscripcion);
            ps.setTime(11, horaCierreInscripcion);
            ps.setString(12, condiciones);
            ps.setInt(13, idEvento);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    public void cambiarEstado(int idEvento, int estado) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Evento SET estado = ? WHERE idEvento = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, estado);
            ps.setInt(2, idEvento);
            
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public void rechazarCondicionEventoCondiciones(String condiciones, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Evento SET condiciones = ? WHERE idEvento = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, condiciones);
            ps.setInt(2, idEvento);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    
}
