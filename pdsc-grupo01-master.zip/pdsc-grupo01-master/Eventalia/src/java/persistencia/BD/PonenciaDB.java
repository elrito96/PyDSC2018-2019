/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import serviciosComunes.ConnectionPool;

/**
 *
 * @author Ivan
 */
public class PonenciaDB {

    public void agregarPonentes(int idEvento, String[] seleccion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        System.out.println("Funciono Database");
        String query = "INSERT INTO Ponencia (idUsuario, idEvento) VALUES(?,?)";
        try {
            ps = connection.prepareStatement(query);
            for (String idUsuario : seleccion) {
                ps.setInt(1, Integer.parseInt(idUsuario));
                ps.setInt(2, idEvento);
                ps.executeUpdate();
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
}
