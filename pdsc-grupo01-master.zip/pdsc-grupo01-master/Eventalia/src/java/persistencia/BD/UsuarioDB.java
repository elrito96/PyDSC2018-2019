package persistencia.BD;

import serviciosComunes.ConnectionPool;
import java.sql.*;
import java.util.ArrayList;

public class UsuarioDB {

    public void insertarUsuario(String nombre, String apellidos, int tipoUsuario, String login, String correo, String password, Boolean administrador) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO Usuario (nombre,apellidos,tipoUsuario,login,correo,password,administrador) VALUES(?,?,?,?,?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setInt(3, tipoUsuario);
            ps.setString(4, login);
            ps.setString(5, correo);
            ps.setString(6, password);
            ps.setInt(7, administrador ? 1 : 0);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public boolean emailExists(String emailAddress) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT correo FROM Usuario WHERE correo= ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1,emailAddress );
            rs = ps.executeQuery();
            boolean res= rs.next();
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean loginExists(String login) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT login FROM Usuario WHERE login= ?";

        try {
            ps = connection.prepareStatement(query);
            ps.setString(1,login );
            rs = ps.executeQuery();
            boolean res= rs.next();
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ArrayList<Object> identificarse(String login, String password) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM Usuario WHERE login= ? AND password = ?";
        
        ArrayList<Object> users = new ArrayList<>();
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1,login);
            ps.setString(2,password);
            rs = ps.executeQuery(); 
            while (rs.next()) {
                users.add(rs.getInt("idUsuario"));
                users.add(rs.getString("nombre"));
                users.add(rs.getString("apellidos"));
                users.add(rs.getInt("tipoUsuario"));
                users.add(rs.getString("login"));
                users.add(rs.getString("correo"));
                users.add(rs.getString("password"));  
                users.add(rs.getInt("administrador"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    
    public int dameAdmin (int idUser) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT administrador FROM Usuario WHERE idUsuario= ?";
        
        int res = -1;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1,idUser);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                res = rs.getInt("administrador");
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return res;
        }
    }
    public boolean estaInscrito(int idSesion, int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM Inscripcion WHERE idUsuario = "+idUsuario+" AND idSesion = "+idSesion;
        System.out.println(query);
        boolean res=false;
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            
            if(rs.next()) {
                res = true;
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            System.out.println(res);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return res;
        }
    }
    public boolean esOrganizador(int idUsuario, int idEvento){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM Organizacion WHERE idUsuario = "+idUsuario+" AND idEvento = "+idEvento;
        System.out.println(query);
        boolean res=false;
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            
            if(rs.next()) {
                res = true;
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            System.out.println(res);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return res;
        }
    }

    public ArrayList getListaCompleta() {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT U.idUsuario, U.nombre, U.apellidos, U.tipoUsuario FROM Usuario U ORDER BY U.nombre asc ";
        
        ArrayList<Object> users = new ArrayList<>();
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery(); 
            while (rs.next()) {
                users.add(rs.getInt("idUsuario"));
                users.add(rs.getString("nombre"));
                users.add(rs.getString("apellidos"));
                users.add(rs.getInt("tipoUsuario"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    
}
