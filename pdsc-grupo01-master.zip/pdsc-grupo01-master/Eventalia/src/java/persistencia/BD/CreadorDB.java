package persistencia.BD;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import serviciosComunes.ConnectionPool;

public class CreadorDB {

    public int getIdCreador(int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int idUsuario=0;
        String query = "SELECT idUsuario FROM Creacion WHERE idEvento = "+idEvento ;
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                idUsuario= rs.getInt("idUsuario");
            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();  
        } 
        
        pool.freeConnection(connection);
        
        return idUsuario;
    }
  
}
