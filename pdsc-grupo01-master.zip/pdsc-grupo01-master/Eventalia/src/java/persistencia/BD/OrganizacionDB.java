package persistencia.BD;

import serviciosComunes.ConnectionPool;
import java.sql.*;

public class OrganizacionDB {

    public boolean consultaOrganizador(int idUsuario, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM Organizacion WHERE idUsuario = ? AND idEvento = ?";

        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idUsuario);
            ps.setInt(2, idEvento);
            rs = ps.executeQuery();
            boolean res = rs.next();
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void agregarOrganizadoresEvento(int idEvento, String[] seleccion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO Organizacion (idUsuario, idEvento) VALUES(?,?)";
        try {
            ps = connection.prepareStatement(query);
            for (String idUsuario : seleccion) {
                ps.setInt(1, Integer.parseInt(idUsuario));
                ps.setInt(2, idEvento);
                ps.executeUpdate();
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

}
