package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class BuscadorEventoDB {

    public ArrayList<Object> getEventosFiltrados(String filtroR, String filtroE, String filtroT, int idUser, int admin) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();

        if ("'Disponibles'".equals(filtroE) && admin == 0) {
            System.out.println("DISPONIBLE, Eventos aceptados todos los usuarios");
            try {
                ps = connection.prepareStatement("select DISTINCT E.idEvento, E.NOMBRE,"
                        + "E.FECHAINICIOEVENTO, E.HORAINICIOEVENTO, E.ESTADO"
                        + " from Evento E"
                        + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO AND E.ESTADO=1 ORDER BY ESTADO ASC");
                rs = ps.executeQuery();
                while (rs.next()) {
                    infoEvs.add(rs.getInt("idEvento"));
                    infoEvs.add(rs.getString("NOMBRE"));
                    infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                    infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                    infoEvs.add(rs.getInt("ESTADO"));
                }
                rs.close();
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return infoEvs;

        }else if ("'Disponibles'".equals(filtroE) && admin == 1) {
            System.out.println("DISPONIBLE, Todos los eventos usuarios admin");
            try {
                ps = connection.prepareStatement("select DISTINCT E.idEvento, E.NOMBRE,"
                        + "E.FECHAINICIOEVENTO, E.HORAINICIOEVENTO, E.ESTADO"
                        + " from Evento E"
                        + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO "
                        + " AND (E.ESTADO = 1 OR E.ESTADO = 3 OR E.ESTADO = 0) "
                        + "ORDER BY ESTADO ASC");
                rs = ps.executeQuery();
                while (rs.next()) {
                    infoEvs.add(rs.getInt("idEvento"));
                    infoEvs.add(rs.getString("NOMBRE"));
                    infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                    infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                    infoEvs.add(rs.getInt("ESTADO"));
                }
                rs.close();
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return infoEvs;

        }else if ("'Mis Eventos'".equals(filtroE)) {
            System.out.println("MIS EventoS");
            if ("'Creador'".equals(filtroR)) {
                System.out.println("CREADOR");
                //Es para JDBC, en MYSQL vale con un enum
                int filtroTJDBC = filtro(filtroT);
                if (filtroTJDBC == 4) {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO, E.HORAINICIOEVENTO, E.ESTADO"
                                + " from Evento E, Creacion C"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND C.IDEVENTO=E.IDEVENTO AND C.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO, E.ESTADO"
                                + " from Evento E, Creacion C"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND E.ESTADO=" + filtroTJDBC
                                + " AND C.IDEVENTO=E.IDEVENTO AND C.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                return infoEvs;
            } else if ("'Organizador'".equals(filtroR)) {
                System.out.println("ORGANIZADOR");
                //Es para JDBC, en MYSQL vale con un enum
                int filtroTJDBC = filtro(filtroT);
                if (filtroTJDBC == 4) {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO,E.ESTADO"
                                + " from Evento E, Organizacion O"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND O.IDEVENTO=E.IDEVENTO AND O.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO, E.ESTADO"
                                + " from Evento E, Organizacion O"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND E.ESTADO=" + filtroTJDBC
                                + " AND O.IDEVENTO=E.IDEVENTO AND O.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                return infoEvs;
            } else if ("'Ponente'".equals(filtroR)) {
                System.out.println("PONENTE");
                //Es para JDBC, en MYSQL vale con un enum
                int filtroTJDBC = filtro(filtroT);
                if (filtroTJDBC == 4) {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO, E.ESTADO"
                                + " from Evento E, Ponencia P"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND P.IDEVENTO=E.IDEVENTO AND P.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO, E.ESTADO"
                                + " from Evento E, Ponencia P"
                                + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                                + " AND E.ESTADO=" + filtroTJDBC
                                + " AND P.IDEVENTO=E.IDEVENTO AND P.IDUSUARIO=" + idUser + " ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                return infoEvs;
            } else {
                System.out.println("TODO");
                //Es para JDBC, en MYSQL vale con un enum
                int filtroTJDBC = filtro(filtroT);
                if (filtroTJDBC == 4) {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO,E.ESTADO"
                                + " from Evento E, Organizacion O, Creacion C, Ponencia P"
                                + " WHERE "
                                + " (O.IDEVENTO=E.IDEVENTO AND O.IDUSUARIO=" + idUser
                                + ")OR( C.IDEVENTO=E.IDEVENTO AND C.IDUSUARIO=" + idUser
                                + ")OR( P.IDEVENTO=E.IDEVENTO AND P.IDUSUARIO=" + idUser + ")");
                        
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        ps = connection.prepareStatement("select DISTINCT E.idEvento,E.NOMBRE,"
                                + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO,E.ESTADO"
                                + " from Evento E, Organizacion O, Creacion C, Ponencia P"
                                + " WHERE "
                                + "  E.ESTADO=" + filtroTJDBC
                                + " AND ((O.IDEVENTO=E.IDEVENTO AND O.IDUSUARIO=" + idUser
                                + ")OR( C.IDEVENTO=E.IDEVENTO AND C.IDUSUARIO=" + idUser
                                + ")OR( P.IDEVENTO=E.IDEVENTO AND P.IDUSUARIO=" + idUser + ")) ORDER BY ESTADO ASC");
                        rs = ps.executeQuery();
                        
                        while (rs.next()) {
                            infoEvs.add(rs.getInt("idEvento"));
                            infoEvs.add(rs.getString("NOMBRE"));
                            infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                            infoEvs.add(rs.getTime("HORAINICIOEVENTO"));
                            infoEvs.add(rs.getInt("ESTADO"));
                        }
                        rs.close();
                        ps.close();
                        pool.freeConnection(connection);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                return infoEvs;

            }

        }
        return infoEvs;
    }

    private int filtro(String filtroT) {
        int filtroTJDBC;
        if (null == filtroT) {
            filtroTJDBC = 4;
        } else {
            switch (filtroT) {
                case "'Pend. Aprobacion'":
                    filtroTJDBC = 0;
                    break;
                case "'Aprobado'":
                    filtroTJDBC = 1;
                    break;
                case "'Denegado'":
                    filtroTJDBC = 2;
                    break;
                case "'Condicional'":
                    filtroTJDBC = 3;
                    break;
                default:
                    filtroTJDBC = 4;
                    break;
            }
        }
        return filtroTJDBC;
    }
}
