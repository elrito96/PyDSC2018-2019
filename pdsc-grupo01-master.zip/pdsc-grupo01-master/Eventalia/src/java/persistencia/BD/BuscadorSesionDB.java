package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class BuscadorSesionDB {

    public ArrayList<Object> getSesionesFiltradas(String filtroR, String filtroE, int idUser) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoSes = new ArrayList<>();

        if ("'Disponibles'".equals(filtroE)) {

            try {
                ps = connection.prepareStatement("select DISTINCT E.NOMBRE,"
                        + "E.FECHAINICIOEVENTO,S.LUGAR,S.HORAINICIOSESION, S.IDSESION"
                        + " from Sesion S, Evento E"
                        + " WHERE S.IDEVENTO=E.IDEVENTO AND CURRENT_DATE <= E.FECHAINICIOEVENTO AND E.ESTADO=1");
                rs = ps.executeQuery();
                while (rs.next()) {
                    infoSes.add(rs.getInt("idSesion"));
                    infoSes.add(rs.getString("LUGAR"));
                    infoSes.add(rs.getTime("HORAINICIOSESION"));
                    infoSes.add(rs.getString("NOMBRE"));
                    infoSes.add(rs.getDate("FECHAINICIOEVENTO"));
                }
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return infoSes;

        } else if ("'Mis Sesiones'".equals(filtroE)) {

            if ("'Asistente'".equals(filtroR)) {

                //Es para JDBC, en MYSQL vale con un enum
                try {
                    ps = connection.prepareStatement("select DISTINCT E.NOMBRE,"
                            + "E.FECHAINICIOEVENTO,S.LUGAR,S.HORAINICIOSESION,S.IDSESION"
                            + " from Sesion S, Evento E, Asistencia A"
                            + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                            + " AND S.IDEVENTO=E.IDEVENTO AND A.IDSESION=S.IDSESION AND A.IDUSUARIO=" + idUser);
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        infoSes.add(rs.getInt("IDSESION"));
                        infoSes.add(rs.getString("LUGAR"));
                        infoSes.add(rs.getTime("HORAINICIOSESION"));
                        infoSes.add(rs.getString("NOMBRE"));
                        infoSes.add(rs.getDate("FECHAINICIOEVENTO"));
                    }

                    ps.close();
                    pool.freeConnection(connection);

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                return infoSes;
            } else if ("'Inscrito'".equals(filtroR)) {

                try {
                    ps = connection.prepareStatement("select DISTINCT E.NOMBRE,"
                            + "E.FECHAINICIOEVENTO,S.LUGAR,S.HORAINICIOSESION,S.IDSESION"
                            + " from Sesion S, Evento E, Inscripcion I"
                            + " WHERE CURRENT_DATE <= E.FECHAINICIOEVENTO"
                            + " AND S.IDEVENTO=E.IDEVENTO AND I.IDSESION=S.IDSESION AND I.IDUSUARIO=" + idUser);
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        infoSes.add(rs.getInt("IDSESION"));
                        infoSes.add(rs.getString("LUGAR"));
                        infoSes.add(rs.getTime("HORAINICIOSESION"));
                        infoSes.add(rs.getString("NOMBRE"));
                        infoSes.add(rs.getDate("FECHAINICIOEVENTO"));
                    }

                    ps.close();
                    pool.freeConnection(connection);
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                return infoSes;
            } else {
                //Es para JDBC, en MYSQL vale con un enum

                try {
                    ps = connection.prepareStatement("select DISTINCT E.NOMBRE,"
                            + "E.FECHAINICIOEVENTO,S.LUGAR,S.HORAINICIOSESION, S.IDSESION"
                            + " from Sesion S, Evento E, Asistencia A, Inscripcion I"
                            + " WHERE S.IDEVENTO=E.IDEVENTO AND CURRENT_DATE <= E.FECHAINICIOEVENTO"
                            + " AND ((A.IDSESION=S.IDSESION AND A.IDUSUARIO=" + idUser
                            + ")OR( I.IDSESION=S.IDSESION AND I.IDUSUARIO=" + idUser + "))");
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        infoSes.add(rs.getInt("IDSESION"));
                        infoSes.add(rs.getString("LUGAR"));
                        infoSes.add(rs.getTime("HORAINICIOSESION"));
                        infoSes.add(rs.getString("NOMBRE"));
                        infoSes.add(rs.getDate("FECHAINICIOEVENTO"));
                    }

                    ps.close();
                    pool.freeConnection(connection);

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                return infoSes;

            }

        }
        return infoSes;
    }
}
