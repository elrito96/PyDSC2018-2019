package persistencia.BD;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class SesionDB {

    public void insertarSesion(String lugar, int cupoMaximo, String comentario, Time horaInicioSesion, Time horaFinalSesion, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO Sesion (lugar, cupoMaximo, comentario, horaInicioSesion, horaFinalSesion, idEvento) VALUES(?,?,?,?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, lugar);
            ps.setInt(2, cupoMaximo);
            ps.setString(3, comentario);
            ps.setTime(4, horaInicioSesion);
            ps.setTime(5, horaFinalSesion);
            ps.setInt(6, idEvento);

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public void inscripcionSesion(int idSesion, int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int numInscritos = 0;

        String query = "SELECT COUNT (I.IDSESION) AS numInscritos FROM Inscripcion I"
                + " WHERE I.IDSESION=" + idSesion;

        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                numInscritos = rs.getInt("numInscritos");
            }
            rs.close();
            ps.close();
            System.out.println(numInscritos);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        query = "INSERT INTO Inscripcion (idUsuario, idSesion, posicionEspera) VALUES(?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idUsuario);
            ps.setInt(2, idSesion);
            ps.setInt(3, numInscritos + 1);

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public ArrayList<Object> getListaSesionesEvento(int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoSes = new ArrayList<>();

        try {
            ps = connection.prepareStatement("select DISTINCT E.NOMBRE,"
                    + "E.FECHAINICIOEVENTO,S.LUGAR,S.HORAINICIOSESION, S.IDSESION, S.CUPOMAXIMO"
                    + " from Sesion S, Evento E"
                    + " WHERE S.IDEVENTO=E.IDEVENTO AND S.IDEVENTO=" + idEvento);
            rs = ps.executeQuery();
            while (rs.next()) {
                infoSes.add(rs.getInt("idSesion"));
                infoSes.add(rs.getString("LUGAR"));
                infoSes.add(rs.getTime("HORAINICIOSESION"));
                infoSes.add(rs.getString("NOMBRE"));
                infoSes.add(rs.getDate("FECHAINICIOEVENTO"));
                infoSes.add(rs.getInt("cupoMaximo"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return infoSes;

    }

    public void eliminarSesion(int idSesion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "DELETE FROM Inscripcion WHERE IDSESION = "+idSesion;
        try {
            ps = connection.prepareStatement(query);
            ps.executeUpdate();
            query = "DELETE FROM Sesion WHERE IDSESION= " + idSesion;
            ps = connection.prepareStatement(query);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }

    public void cancelarInscripcionSesion(int idSesion, int idUsuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int posAct = 0;

        String query = "SELECT I.POSICIONESPERA FROM Inscripcion I WHERE I.IDSESION="+idSesion+" AND I.IDUSUARIO=" + idUsuario;
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                posAct = rs.getInt("POSICIONESPERA");
            }
            rs.close();
            ps.close();
            
            query = "DELETE FROM Inscripcion WHERE IDUSUARIO= " + idUsuario;
            ps = connection.prepareStatement(query);
            ps.executeUpdate();
            ps.close();

            query = "UPDATE Inscripcion I SET I.POSICIONESPERA=I.POSICIONESPERA-1 WHERE I.POSICIONESPERA>" + posAct + " AND I.IDSESION=" + idSesion;
            ps = connection.prepareStatement(query);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    
    public Integer getUsuarioPosicionInscritoSesion(int idSesion, int cm){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Integer> res=new ArrayList<>();
        Integer idUsuario=null;
        try {
            ps = connection.prepareStatement("select I.IDUSUARIO"
                        + " from Inscripcion I"
                        + " WHERE I.IDSESION = "+idSesion);
                
            rs = ps.executeQuery();
          while (rs.next()) {           
                res.add(rs.getInt("IDUSUARIO"));
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(res.size()>cm-1){
            idUsuario = res.get(cm-1);
        }
        return idUsuario;
    }
}
