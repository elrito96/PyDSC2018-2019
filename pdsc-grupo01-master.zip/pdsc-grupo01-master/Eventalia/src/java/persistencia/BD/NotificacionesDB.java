package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class NotificacionesDB {

    public  ArrayList<String> getNotificacionesEventos(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> notificaciones = new ArrayList<String>();
        try {
            ps = connection.prepareStatement("select *"
                    + " FROM NotificacionesE N"
                    + " WHERE N.idUsuario = "+idUsuario);
            rs = ps.executeQuery();
          while (rs.next()) {           
                notificaciones.add(rs.getString("notificacion"));            
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }     
        return notificaciones;
    }
    public int getContadorEventos(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int contador = 0;
        try {
            ps = connection.prepareStatement("select count(*) as conteo"
                    + " FROM NotificacionesE"
                    + " WHERE visto = 0 AND idUsuario = "+idUsuario);
            rs = ps.executeQuery();
          while (rs.next()) {           
                contador = rs.getInt("conteo");
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
      
        return contador;
    }
    public void addNotificacionE(int idUsuario, int idEvento, String notificacion, int visto ){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO NotificacionesE VALUES(?,?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idUsuario);
            ps.setInt(2, idEvento);
            ps.setString(3, notificacion);
            ps.setInt(4, visto);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    public void verNotificaciones(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE NotificacionesE SET visto = ? WHERE idUsuario = "+idUsuario;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, 1);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    // Parte de notificaciones de lista de espera
    public  ArrayList<String> getNotificacionesLista(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<String> notificaciones = new ArrayList<String>();
        try {
            ps = connection.prepareStatement("select *"
                    + " FROM NotificacionesL N"
                    + " WHERE N.idUsuario = "+idUsuario);
            rs = ps.executeQuery();
          while (rs.next()) {           
                notificaciones.add(rs.getString("notificacion"));            
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notificaciones;
    }
    public int getContadorLista(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int contador = 0;
        try {
            ps = connection.prepareStatement("select count(*) as conteo"
                    + " FROM NotificacionesL"
                    + " WHERE visto = 0 AND idUsuario = "+idUsuario);
            rs = ps.executeQuery();
          while (rs.next()) {           
                contador = rs.getInt("conteo");
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
      
        return contador;
    }
    public void addNotificacionL(int idUsuario, int idEvento, String notificacion, int visto ){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        String query = "INSERT INTO NotificacionesL VALUES(?,?,?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, idUsuario);
            ps.setInt(2, idEvento);
            ps.setString(3, notificacion);
            ps.setInt(4, visto);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
    public void verNotificacionesL(int idUsuario){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE NotificacionesL SET visto = ? WHERE idUsuario = "+idUsuario;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, 1);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        pool.freeConnection(connection);
    }
}