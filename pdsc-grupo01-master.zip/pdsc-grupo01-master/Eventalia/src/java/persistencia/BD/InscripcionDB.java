package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class InscripcionDB {

    public int dameInscritos(int idSesion) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int res = 0;
        try {
            ps = connection.prepareStatement("select COUNT(*) as numeroInscritos"
                        + " from Inscripcion I"
                        + " WHERE I.idSesion =" + idSesion);
            rs = ps.executeQuery();
            while (rs.next()) {
                res = rs.getInt("numeroInscritos");
            }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }
    
}
