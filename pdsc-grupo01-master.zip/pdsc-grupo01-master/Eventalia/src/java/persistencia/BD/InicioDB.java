package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class InicioDB {

    public  ArrayList <Object> getEventosProximos(){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> infoEvs = new ArrayList<>();
 
        try {
            ps = connection.prepareStatement("select E.NOMBRE,"
                    + "E.FECHAINICIOEVENTO,E.HORAINICIOEVENTO"
                    + " from Evento E"
                    + " WHERE E.ESTADO = 1 AND CURRENT_DATE <= E.FECHAINICIOEVENTO");
            rs = ps.executeQuery();
          while (rs.next()) {           
                infoEvs.add(rs.getString("NOMBRE"));            
                infoEvs.add(rs.getDate("FECHAINICIOEVENTO"));
                infoEvs.add(rs.getTime("HORAINICIOEVENTO"));          }
            ps.close();
            pool.freeConnection(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
        return infoEvs;
    }
}