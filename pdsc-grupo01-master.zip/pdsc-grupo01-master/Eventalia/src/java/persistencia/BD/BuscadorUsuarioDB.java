package persistencia.BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import serviciosComunes.ConnectionPool;

public class BuscadorUsuarioDB {

    public ArrayList<Object> getUsuariosFiltrados(String filtroE, int idEvento) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> users = new ArrayList<>();

        if ("'Ponente'".equals(filtroE)) {

            try {
                ps = connection.prepareStatement("select DISTINCT U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                        + " from Usuario U"
                        + " WHERE U.IDUSUARIO  NOT IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ")");
                rs = ps.executeQuery();
                while (rs.next()) {
                    users.add(rs.getInt("IDUSUARIO"));
                    users.add(rs.getString("NOMBRE"));
                    users.add(rs.getString("APELLIDOS"));
                    users.add(rs.getString("LOGIN"));
                }
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return users;

        } else if ("'Organizador'".equals(filtroE)) {

            try {
                ps = connection.prepareStatement("select DISTINCT U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                        + " from Usuario U"
                        + " WHERE U.IDUSUARIO  NOT IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                rs = ps.executeQuery();
                while (rs.next()) {
                    users.add(rs.getInt("IDUSUARIO"));
                    users.add(rs.getString("NOMBRE"));
                    users.add(rs.getString("APELLIDOS"));
                    users.add(rs.getString("LOGIN"));
                }
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return users;
        } else {
            try {
                int cupMax = 0;
                ps = connection.prepareStatement("select S.CUPOMAXIMO"
                        + " from Sesion S"
                        + " WHERE S.IDSESION=" + idEvento);
                rs = ps.executeQuery();
                while (rs.next()) {

                    cupMax = rs.getInt("CUPOMAXIMO");
                }
                
                ps = connection.prepareStatement("select DISTINCT U.IDUSUARIO, U.NOMBRE, U.APELLIDOS, U.LOGIN"
                        + " from Inscripcion I, Usuario U, Sesion S"
                        + " WHERE U.IDUSUARIO=I.IDUSUARIO AND I.IDSESION=" + idEvento + " AND I.IDSESION=S.IDSESION AND I.POSICIONESPERA<=" + cupMax);
                rs = ps.executeQuery();
                while (rs.next()) {
                    users.add(rs.getInt("IDUSUARIO"));
                    users.add(rs.getString("NOMBRE"));
                    users.add(rs.getString("APELLIDOS"));
                    users.add(rs.getString("LOGIN"));
                }
                ps.close();
                pool.freeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return users;
        }
    }

    public ArrayList<Object> getListaUsuariosFiltrados(String filtroR, String filtroS, String filtroT, String filtroP, int idEvento) {

        /*
        filtroR: Todo,Organizadores,Ponentes
        filtroS: Todo,1,4,5 (idsSesion)
        filtroP: Todo,Asistente,Inscrito
        filtroT: Todo,Alumnos,PID,PAS,Usuarios Externos      
         */
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Object> users = new ArrayList<>();
        if ("Todo".equals(filtroT)) {
            if ("Todas".equals(filtroS)) {

                if ("'Organizadores'".equals(filtroR)) {

                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));
                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE, U.APELLIDOS, U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }

                } else if ("'Ponentes'".equals(filtroR)) {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                } else {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A) AND "
                                    + " (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I) AND"
                                    + " (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Sesion S"
                                    + " WHERE (U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION IN (SELECT S.IDSESION FROM Sesion S WHERE S.IDEVENTO="+idEvento+")) OR "
                                    + " U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION IN (SELECT S.IDSESION FROM Sesion S WHERE S.IDEVENTO="+idEvento+")))"
                                    + " OR (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                }
            } else {

                int filtroS1 = Integer.parseInt(filtroS);
                if ("'Organizadores'".equals(filtroR)) {

                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));
                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }

                } else if ("'Ponentes'".equals(filtroR)) {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                } else {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")"
                                    + " AND ( U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")"
                                    + " AND( U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Sesion S"
                                    + " WHERE U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ") OR "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")"
                                    + " OR U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                }
            }
        } else {
            if ("Todas".equals(filtroS)) {

                if ("'Organizadores'".equals(filtroR)) {

                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));
                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE, U.APELLIDOS, U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.TIPOUSUARIO=" + 0 + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }

                } else if ("'Ponentes'".equals(filtroR)) {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I)");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                } else {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A)"
                                    + " AND (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I)"
                                    + " AND (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Sesion S"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND (U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A) OR "
                                    + " U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I))"
                                    + " AND (U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") OR "
                                    + " U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                }
            } else {

                int filtroS1 = Integer.parseInt(filtroS);
                if ("'Organizadores'".equals(filtroR)) {

                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));
                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT O.IDUSUARIO FROM Organizacion O WHERE O.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }

                } else if ("'Ponentes'".equals(filtroR)) {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Evento E"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT P.IDUSUARIO FROM Ponencia P WHERE P.IDEVENTO=" + idEvento + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                } else {
                    if ("'Asistente'".equals(filtroP)) {

                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;

                    } else if ("'Inscrito'".equals(filtroP)) {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + ")");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    } else {
                        try {
                            ps = connection.prepareStatement("select DISTINCT  U.TIPOUSUARIO, U.IDUSUARIO, U.NOMBRE,U.APELLIDOS,U.LOGIN"
                                    + " from Usuario U, Sesion S"
                                    + " WHERE U.TIPOUSUARIO=" + filtroT + " AND (U.IDUSUARIO IN (SELECT A.IDUSUARIO FROM Asistencia A WHERE A.IDSESION=" + filtroS1 + ") AND "
                                    + "U.IDUSUARIO IN (SELECT I.IDUSUARIO FROM Inscripcion I WHERE I.IDSESION=" + filtroS1 + "))");
                            rs = ps.executeQuery();
                            while (rs.next()) {
                                users.add(rs.getInt("IDUSUARIO"));
                                users.add(rs.getString("NOMBRE"));
                                users.add(rs.getString("APELLIDOS"));
                                users.add(rs.getInt("TIPOUSUARIO"));

                                users.add(rs.getString("LOGIN"));
                            }
                            ps.close();
                            pool.freeConnection(connection);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return users;
                    }
                }
            }
        }
    }
}
