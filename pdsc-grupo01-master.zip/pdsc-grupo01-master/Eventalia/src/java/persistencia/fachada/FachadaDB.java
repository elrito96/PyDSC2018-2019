package persistencia.fachada;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;

import persistencia.BD.*;

public class FachadaDB {

    private InicioDB inicioDB = new InicioDB();
    private UsuarioDB usuarioDB = new UsuarioDB();
    private BuscadorEventoDB buscEvDB = new BuscadorEventoDB();
    private EventoDB eventoDB = new EventoDB();
    private BuscadorSesionDB buscSeDB = new BuscadorSesionDB();
    private EventoConcretoDB eventoConcretoDB = new EventoConcretoDB();
    private OrganizacionDB organizacionDB = new OrganizacionDB();
    private SesionDB sesionDB = new SesionDB();
    private SesionConcretaDB sesionConcretaDB = new SesionConcretaDB();
    private CreadorDB creadorDB = new CreadorDB();

    private NotificacionesDB notificacionesDB = new NotificacionesDB();

    private BuscadorUsuarioDB buscUsDB = new BuscadorUsuarioDB();
    private PonenciaDB ponenciaDB = new PonenciaDB();
    private AsistenciaDB asistenciaDB = new AsistenciaDB();
    private InformeDB informeDB = new InformeDB();
    private InscripcionDB inscripcionDB = new InscripcionDB();
    
    public ArrayList<Object> getSesionesFiltradas(String filtroRQ, String filtroEQ, int idUser) {
        ArrayList infoSes = buscSeDB.getSesionesFiltradas(filtroRQ, filtroEQ, idUser);
        return infoSes;
    }

    public ArrayList<Object> getUsuariosFiltrados(String filtroE, int idEvento) {
        ArrayList users = buscUsDB.getUsuariosFiltrados(filtroE, idEvento);
        return users;
    }
    
    public ArrayList<Object> getListaUsuariosFiltrados(String filtroR, String filtroS, String filtroT,String filtroP, int idEvento) {
        ArrayList users = buscUsDB.getListaUsuariosFiltrados(filtroR, filtroS, filtroT, filtroP,idEvento);
        return users;
    }

    public ArrayList<Object> getEventosProximos() {
        ArrayList infoEvs = inicioDB.getEventosProximos();
        return infoEvs;
    }

    public ArrayList<Object> getEventosFiltrados(String filtroRQ, String filtroEQ, String filtroTQ, int idUser) {
        int admin = usuarioDB.dameAdmin(idUser);
        ArrayList infoEvs = buscEvDB.getEventosFiltrados(filtroRQ, filtroEQ, filtroTQ, idUser, admin);
        return infoEvs;
    }

    public void insertarUsuario(String nombre, String apellidos, int tipoUsuario, String login, String correo, String password, Boolean administrador) {
        usuarioDB.insertarUsuario(nombre, apellidos, tipoUsuario, login, correo, password, administrador);
    }

    public void agregarPonenteEvento(int idEvento, String[] seleccion) {
        ponenciaDB.agregarPonentes(idEvento, seleccion);
    }

    public void agregarOrganizadorEvento(int idEvento, String[] seleccion) {
        organizacionDB.agregarOrganizadoresEvento(idEvento, seleccion);
    }

    public void registraAsistencia(int idSesion, String[] seleccion) {
        asistenciaDB.registraAsistencia(idSesion, seleccion);
    }

    public boolean loginExists(String login) {
        return usuarioDB.loginExists(login);
    }

    public boolean emailExists(String correo) {
        return usuarioDB.emailExists(correo);
    }

    public ArrayList<Object> identificarse(String login, String password) {
        return usuarioDB.identificarse(login, password);
    }

    public void insertarEvento(String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion) {
        eventoDB.insertarEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion);
    }

    public int selectIdEvento(String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento) {
        return eventoDB.selectIdEvento(nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento);
    }

    public void insertarCreadorEvento(int idCreador, int idEvento) {
        eventoDB.insertarCreadorEvento(idCreador, idEvento);
    }

    public void insertarOrganizadorEvento(int idOrganizador, int idEvento) {
        eventoDB.insertarOrganizadorEvento(idOrganizador, idEvento);
    }

    public ArrayList<Object> consultaEventoConcreto(int idEvento) {
        return eventoConcretoDB.consultaEventoConcreto(idEvento);
    }

    public boolean consultaOrganizador(int idUsuario, int idEvento) {
        return organizacionDB.consultaOrganizador(idUsuario, idEvento);
    }

    public void insertarSesion(String lugar, int cupoMaximo, String condiciones, Time horaInicioSesion, Time horaFinalSesion, int idEvento) {
        sesionDB.insertarSesion(lugar, cupoMaximo, condiciones, horaInicioSesion, horaFinalSesion, idEvento);
    }

    public void modificarEvento(int idEvento, String nombre, String descripcion, int estado, Date fechaInicioEvento, Time horaInicioEvento, Date fechaFinEvento, Time horaFinEvento, Date fechaAperturaInscripcion, Date fechaCierreInscripcion, Time horaAperturaInscripcion, Time horaCierreInscripcion, String condiciones) {
        eventoDB.modificarEvento(idEvento, nombre, descripcion, estado, fechaInicioEvento, horaInicioEvento, fechaFinEvento, horaFinEvento, fechaAperturaInscripcion, fechaCierreInscripcion, horaAperturaInscripcion, horaCierreInscripcion, condiciones);
    }

    public void cambiarEstado(int idEvento, int estado) {
        eventoDB.cambiarEstado(idEvento, estado);

    }

    public void addNotificacionE(int idUsuario, int idEvento, String not, int visto) {
        notificacionesDB.addNotificacionE(idUsuario, idEvento, not, visto);
    }

    public void rechazarCondicionEvento(String condiciones, int idEvento) {
        eventoDB.rechazarCondicionEventoCondiciones(condiciones, idEvento);
        //notificacionesDB.addNotificacionE(idUsuario, idEvento, not, visto);
    }

    public ArrayList<Object> consultaSesionConcreta(int idSesion) {
        return sesionConcretaDB.consultaSesionConcreta(idSesion);
    }

    public void inscripcionSesion(int idSesion, int idUsuario) {
        sesionDB.inscripcionSesion(idSesion, idUsuario);
    }

    public ArrayList<Object> getListaSesionesEvento(int idEvento) {
        return sesionDB.getListaSesionesEvento(idEvento);
    }

    public void eliminarSesion(int idSesion) {
        sesionDB.eliminarSesion(idSesion);
    }

    public void cancelarInscripcionSesion(int idSesion, int idUsuario) {
        sesionDB.cancelarInscripcionSesion(idSesion, idUsuario);
    }

    public ArrayList<String> getNotificacionesEventos(int idUsuario) {
        ArrayList<String> notif = notificacionesDB.getNotificacionesEventos(idUsuario);
        return notif;
    }

    public int getContadorNotificaciones(int idUsuario) {
        int cont = notificacionesDB.getContadorEventos(idUsuario);
        return cont;
    }

    public int getIdCreador(int idEvento) {
        return creadorDB.getIdCreador(idEvento);
    }

    public void verNotificacionesE(int id) {
        notificacionesDB.verNotificaciones(id);
    }
    
    public ArrayList<String> getNotificacionesLista(int idUsuario) {
        ArrayList<String> notif = notificacionesDB.getNotificacionesLista(idUsuario);
        return notif;
    }
    public int getContadorNotificacionesL(int idUsuario){
        int cont = notificacionesDB.getContadorLista(idUsuario);
        return cont;
    }
    public void verNotificacionesL(int id){
        notificacionesDB.verNotificacionesL(id);
    }
    public Integer getUsuarioPosicionInscritoSesion(int idSesion, int cm){
        return sesionDB.getUsuarioPosicionInscritoSesion(idSesion,cm);
    }
    public void addNotificacionL(int idUsuario, int idSesion, String not, int visto){
        notificacionesDB.addNotificacionL(idUsuario, idSesion, not, visto);
    }
    public boolean estaInscrito(int idUsuario,int idSesion){
        return usuarioDB.estaInscrito(idUsuario, idSesion);
    }
    public boolean esOrganizador(int idUsuario,int idSesion){
        return usuarioDB.esOrganizador(idUsuario, idSesion);
    }
    public int dameAsistentes(int idSesion) {
        return asistenciaDB.dameAsistentes(idSesion);
    }

    public ArrayList<Object> listaEventosPeriodo(Date fechaPrimera, Date fechaSegunda) {
        return informeDB.listaEventosPeriodo(fechaPrimera,fechaSegunda);
    }

    public ArrayList<Object> dameEventosCreador(int idUsuario) {
        return informeDB.dameEventosCreador(idUsuario);
    }

    public ArrayList<Object> dameEventosOrganizador(int idUsuario) {
        return informeDB.dameEventosOrganizador(idUsuario);
    }

    public ArrayList<Object> dameEventosPonente(int idUsuario) {
        return informeDB.dameEventosPonente(idUsuario);
    }

    public ArrayList<Object> dameEventosInscrito(int idUsuario) {
        return informeDB.dameEventosInscrito(idUsuario);
    }

    public ArrayList<Object> dameEventosAsistido(int idUsuario) {
        return informeDB.dameEventosAsistido(idUsuario);
    }
    public int dameInscritos(int idSesion) {
        return inscripcionDB.dameInscritos(idSesion);
    }

    public ArrayList geListaCompleta() {
        return usuarioDB.getListaCompleta();
    }
}
