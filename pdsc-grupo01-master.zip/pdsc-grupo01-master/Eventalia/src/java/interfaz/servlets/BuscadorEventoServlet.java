/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz.servlets;


import negocio.modelos.Usuario;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Evento;

/**
 *
 * @author Ivan
 */
public class BuscadorEventoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        String url = "";
        Usuario usuario = null;
        HttpSession session = request.getSession();
        usuario = (Usuario) session.getAttribute("user");
        int idUser = usuario.getIdUsuario();
        
        ArrayList<Evento> eventos = null;     
        String filtroRQ = "'" + request.getParameter("FiltroR") + "'";
        String filtroEQ = "'" + request.getParameter("FiltroE") + "'";
        String filtroTQ = "'" + request.getParameter("FiltroT") + "'";
        
        FachadaControladores fachada = new FachadaControladores();
        try {
            eventos = fachada.muestraEventosFiltrados(filtroRQ, filtroEQ,filtroTQ, idUser);
        } catch (SQLException ex) {
            Logger.getLogger(BuscadorEventoServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        request.setAttribute("listaEv", eventos);
        request.setAttribute("esAdmin", usuario.getAdministrador());


        url = "/pages/buscadorEvento.jsp";

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

}
