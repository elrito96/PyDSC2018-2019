
package interfaz.servlets;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;
import negocio.modelos.Sesion;

public class InformeEventoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idEvento = request.getParameter("idEvento");
        
        ArrayList<Integer> datos = new ArrayList<Integer>();
        
        FachadaControladores fachada = new FachadaControladores();
        
        datos.add(fachada.plazasOfertadas(Integer.parseInt(idEvento)));
        datos.add(fachada.numeroInscritos(Integer.parseInt(idEvento)));
        datos.add(fachada.numeroAsistentes(Integer.parseInt(idEvento)));
        
        String url = "/pages/informeEventoConcreto.jsp";
        
        request.setAttribute("informe", datos);
        
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
