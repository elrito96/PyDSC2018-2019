
package interfaz.servlets;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;

public class APaginaCrearSesion extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String eventoSeleccionado=request.getParameter("seleccionEvento");
        
        FachadaControladores fachada = new FachadaControladores();
        
        Evento evento = fachada.consultaEventoConcreto(eventoSeleccionado);
        
        String url = "/pages/crearSesion.jsp";

        request.setAttribute("eventoSeleccionado", evento);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
