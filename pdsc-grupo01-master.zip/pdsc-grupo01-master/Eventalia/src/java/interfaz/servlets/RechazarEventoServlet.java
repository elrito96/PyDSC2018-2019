package interfaz.servlets;

import negocio.fachada.FachadaControladores;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.modelos.Usuario;


@MultipartConfig
public class RechazarEventoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        FachadaControladores fachada = new FachadaControladores();
        HttpSession ses = request.getSession();
        
        String url = "";
        int idEvento = Integer.parseInt(request.getParameter("eventoEntero"));
        int idUsuario = fachada.dameSesion(request).getIdUsuario();
        String nombre = request.getParameter("nombreEvento");
        fachada.cambiarEstado(idEvento, 2, nombre);
        Usuario u = fachada.dameSesion(request);
        request.setAttribute("user", u);
        url = "/pages/panelControl.jsp";
        request.setAttribute("successMessage", "Evento aceptado");
        

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
