
package interfaz.servlets;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;
import negocio.modelos.Sesion;

public class InformeUsuarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idUsuario = request.getParameter("idUsuario");
        
        FachadaControladores fachada = new FachadaControladores();
        
        ArrayList<Evento> evCre = fachada.dameEventosCreador(Integer.parseInt(idUsuario));
        ArrayList<Evento> evOr = fachada.dameEventosOrganizador(Integer.parseInt(idUsuario));
        ArrayList<Evento> evPo = fachada.dameEventosPonente(Integer.parseInt(idUsuario));
        ArrayList<Evento> evIns = fachada.dameEventosInscrito(Integer.parseInt(idUsuario));
        ArrayList<Evento> evAsi = fachada.dameEventosAsistido(Integer.parseInt(idUsuario));
        
        String url = "/pages/informeUsuarioConcreto.jsp";
        
        request.setAttribute("listaEvC", evCre);
        request.setAttribute("listaEvOr", evOr);
        request.setAttribute("listaEvPo", evPo);
        request.setAttribute("listaEvIns", evIns);
        request.setAttribute("listaEvAsi", evAsi);
        
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
