
package interfaz.servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Sesion;


public class APaginaSesion extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String sesionSeleccionada=request.getParameter("seleccionSesion");
        
        FachadaControladores fachada = new FachadaControladores();
        
        Sesion sesion = fachada.consultaSesionConcreta(sesionSeleccionada);
        //0 si no esta inscrito, muestra boton inscribirse|| 1 si esta inscrito muestra boton cancelar
        int idUsuario = fachada.dameSesion(request).getIdUsuario();
        boolean estaInscrito = fachada.estaInscrito(sesion.getIdSesion(),idUsuario);
        boolean esOrganizador = fachada.esOrganizador(idUsuario,sesion.getIdSesion());
        String url = "/pages/sesionSeleccionada.jsp";
              
        request.setAttribute("sesionSeleccionada", sesion);
        request.setAttribute("estaInscrito", estaInscrito);
        request.setAttribute("esOrganizador", esOrganizador);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
