package interfaz.servlets;

import negocio.fachada.FachadaControladores;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@MultipartConfig
public class CrearEventoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        
        String[] f = request.getParameter("fechaInicioEvento").split("-");
        Date fechaInicioEvento = new Date(Integer.parseInt(f[0])-1900,Integer.parseInt(f[1])-1,Integer.parseInt(f[2]));
        f = request.getParameter("fechaFinEvento").split("-");
        Date fechaFinEvento = new Date(Integer.parseInt(f[0])-1900,Integer.parseInt(f[1])-1,Integer.parseInt(f[2]));
        
        f = request.getParameter("horaInicioEvento").split(":");
        Time horaInicioEvento = new Time(Integer.parseInt(f[0]),Integer.parseInt(f[1]),0);
        f = request.getParameter("horaFinEvento").split(":");
        Time horaFinEvento = new Time(Integer.parseInt(f[0]),Integer.parseInt(f[1]),0);
        
        FachadaControladores fachada = new FachadaControladores();
        HttpSession ses = request.getSession();
        
        String url = "";
        fachada.crearEvento(nombre, descripcion, fechaInicioEvento, fechaFinEvento, horaInicioEvento, horaFinEvento,ses);

        url = "/pages/crearEvento.jsp";
        request.setAttribute("successMessage", "Evento creado correctamente. Un administrador revisara el evento para su aprobacion.");
        

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
