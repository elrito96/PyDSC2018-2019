package interfaz.servlets;

import negocio.fachada.FachadaControladores;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.modelos.Evento;


@MultipartConfig
public class CrearSesionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String lugar = request.getParameter("lugar");
        String comentario = request.getParameter("comentario");
        int cupMax = Integer.parseInt(request.getParameter("cupoSesion"));
        
        String[] f = request.getParameter("horaInicioSesion").split(":");
        Time horaInicioSesion = new Time(Integer.parseInt(f[0]),Integer.parseInt(f[1]),0);
        f = request.getParameter("horaFinSesion").split(":");
        Time horaFinSesion = new Time(Integer.parseInt(f[0]),Integer.parseInt(f[1]),0);
        
        FachadaControladores fachada = new FachadaControladores();
        Evento ev = fachada.consultaEventoConcreto(request.getParameter("idEvento"));    
        
        String url = "";
        fachada.crearSesion(lugar, cupMax, comentario, horaInicioSesion, horaFinSesion, ev.getIdEvento());

        url = "/pages/crearSesion.jsp";
        request.setAttribute("eventoSeleccionado", ev);
        request.setAttribute("successMessage", "Sesion creada correctamente.");
        

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
