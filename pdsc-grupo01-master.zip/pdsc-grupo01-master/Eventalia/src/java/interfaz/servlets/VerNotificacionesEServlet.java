package interfaz.servlets;

import negocio.fachada.FachadaControladores;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;


@MultipartConfig
public class VerNotificacionesEServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession ses = request.getSession();
        FachadaControladores fachada = new FachadaControladores();
        int idUsuario = fachada.dameSesion(request).getIdUsuario();
        fachada.verNotificacionesE(idUsuario);
        String url = "/pages/panelControl.jsp";
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        Usuario u = fachada.dameSesion(request);
        request.setAttribute("user", u);
        dispatcher.forward(request, response);

        
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
