package interfaz.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Evento;
import negocio.modelos.Usuario;
import negocio.modelos.Sesion;

public class APaginaEvento extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String eventoSeleccionado = request.getParameter("seleccionEvento");

        FachadaControladores fachada = new FachadaControladores();

        Evento evento = fachada.consultaEventoConcreto(eventoSeleccionado);
        Usuario u = fachada.dameSesion(request);
        ArrayList<Sesion> sesiones = fachada.getSesionesEvento(Integer.parseInt(eventoSeleccionado));
        ArrayList<Usuario> usuarios = null;
        try {
            usuarios = fachada.getlistaUsuariosFiltrados("'Ponentes'", "Todas", "Todo", "Todo", Integer.parseInt(eventoSeleccionado));
        } catch (SQLException ex) {
            Logger.getLogger(APaginaEvento.class.getName()).log(Level.SEVERE, null, ex);
        }
        String url = "/pages/eventoSeleccionado.jsp";

        if (fachada.consultaOrganizador(u.getIdUsuario(), evento.getIdEvento())) {
            request.setAttribute("organizador", true);
        } else {
            request.setAttribute("organizador", false);
        }

        request.setAttribute("usuario", u);
        request.setAttribute("eventoSeleccionado", evento);
        request.setAttribute("listaSe", sesiones);
        request.setAttribute("listaUs", usuarios);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
