package interfaz.servlets;


import negocio.fachada.FachadaControladores;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MostrarNotificacionesEventoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        HttpSession ses = request.getSession();
        ArrayList<String> notificacionesE = null;
        ArrayList<String> notificacionesL = null;
        
        FachadaControladores fachada = new FachadaControladores();
        int idUsuario = fachada.dameSesion(request).getIdUsuario();
        
        int contE = fachada.contadorNotifiacionesEvento(idUsuario);
        notificacionesE = fachada.muestraNotificacionesEvento(idUsuario);
        
        int contL = fachada.contadorNotificacionesLista(idUsuario);
        notificacionesL = fachada.muestraNotificacionesLista(idUsuario);
        
        
        Collections.reverse(notificacionesE);
        Collections.reverse(notificacionesL);
        request.setAttribute("contNotif", contE);
        request.setAttribute("listaNotifEv", notificacionesE);
        request.setAttribute("contNotifL", contL);
        request.setAttribute("listaNotifL", notificacionesL);
        String url = "/pages/notificaciones.jsp";
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
