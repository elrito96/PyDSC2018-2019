package interfaz.servlets;

import negocio.fachada.FachadaControladores;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.modelos.Usuario;



@MultipartConfig
public class AddUsuarioServlet extends HttpServlet {

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellidos = request.getParameter("apellidos");
        String login = request.getParameter("login");
        String correo = request.getParameter("email");
        String password = request.getParameter("password");
        int tipoUsuario = Integer.parseInt(request.getParameter("tipo-usuario"));
        
        FachadaControladores fachada = new FachadaControladores();
        
        String url = "";
        if(fachada.loginExists(login)){
            url= "/pages/registro.jsp";
             request.setAttribute("errorMessage", "Login ya existe. No se ha podido crear el usuario.");
        }else if (fachada.emailExists(correo)) {
            url = "/pages/registro.jsp";
            request.setAttribute("errorMessage", "Email ya existe. No se ha podido crear el usuario.");
        } else {
            fachada.crearUsuario(nombre, apellidos, tipoUsuario, login, correo, password,false);
            
            Usuario user = fachada.identificarse(login,password);
            HttpSession session = request.getSession();
            
            url = "/pages/panelControl.jsp";
            session.setAttribute("user", user);
            
            request.setAttribute("user", user);
        }

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
