package interfaz.servlets;

import negocio.modelos.Usuario;
import negocio.fachada.FachadaControladores;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class IdentificarUsuarioServlet extends HttpServlet {
     
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String login = request.getParameter("login");
        String password = request.getParameter("password");
        
        
        FachadaControladores fachada = new FachadaControladores();
        Usuario user = fachada.identificarse(login,password);
        
        String url = "";
        
        HttpSession session = request.getSession();
        if(user.getIdUsuario()!=0){
            url = "/pages/panelControl.jsp";
            session.setAttribute("user", user);
            request.setAttribute("user", user);
        }else{
            url="/pages/login.jsp";
            request.getSession().invalidate();
            request.logout();
            request.setAttribute("messageError", "Usuario y/o contraseña Incorrectos,introduzca datos correctos.");
        }
            
        
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
