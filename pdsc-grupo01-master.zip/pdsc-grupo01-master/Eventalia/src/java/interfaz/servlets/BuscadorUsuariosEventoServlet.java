package interfaz.servlets;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Usuario;

public class BuscadorUsuariosEventoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String url = "";
        int idEvento = Integer.parseInt(request.getParameter("idEvento"));
      
        ArrayList<Usuario> usuarios = null;
        String filtroEQ = "'" + request.getParameter("FiltroE") + "'";
        FachadaControladores fachada = new FachadaControladores();

        usuarios = fachada.verUsuariosEvento(filtroEQ, idEvento);
        request.setAttribute("listaUs", usuarios);

        url = "/pages/buscadorUsuarios.jsp";

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
