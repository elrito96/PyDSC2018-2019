package interfaz.servlets;

import negocio.modelos.Usuario;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Sesion;

/**
 *
 * @author Ivan
 */
public class ListadorUsuariosInformeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String url = "";

       

        ArrayList<Usuario> usuarios = null;
        FachadaControladores fachada = new FachadaControladores();
        usuarios = fachada.listaCompletaU();
        request.setAttribute("listaUs", usuarios);
        url = "/pages/listaUsuariosInforme.jsp";

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

}
