/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz.servlets;


import negocio.modelos.Usuario;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import negocio.fachada.FachadaControladores;
import negocio.modelos.Sesion;

/**
 *
 * @author Ivan
 */
public class BuscadorSesionServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

       //String titulo = request.getParameter("titulo");
        //String titulo1=titulo.toLowerCase();
        String url = "";
        Usuario usuario = null;
        HttpSession session = request.getSession();
        usuario = (Usuario) session.getAttribute("user");
        int idUser = usuario.getIdUsuario();
        
        ArrayList<Sesion> sesiones = null;     
        String filtroRQ = "'" + request.getParameter("FiltroR") + "'";
        String filtroEQ = "'" + request.getParameter("FiltroE") + "'";
        
        //ArrayList<ResumenContenido> peliculas = PeliculaDB.buscar(filtroRQ, filtroEQ,filtroTQ, titulo1, login);
        FachadaControladores fachada = new FachadaControladores();
        try {
            sesiones = fachada.muestraSesionesFiltradas(filtroRQ, filtroEQ, idUser);
        } catch (SQLException ex) {
            Logger.getLogger(BuscadorSesionServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        request.setAttribute("listaSe", sesiones);


        url = "/pages/buscadorSesion.jsp";

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

}
